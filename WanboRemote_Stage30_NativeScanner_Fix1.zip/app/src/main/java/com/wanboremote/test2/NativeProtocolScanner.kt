package com.wanboremote.test2

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

/**
 * Passive-ish LAN probe for the paired projector. It only opens TCP
 * connections and, for a small set of likely HTTP ports, sends a harmless
 * HEAD request. It never sends projector control commands.
 */
object NativeProtocolScanner {
    private val executor = Executors.newFixedThreadPool(8)

    // Android TV Remote + common EShare / projector service ports.
    private val ports = intArrayOf(
        80, 443, 554, 8000, 8001, 8002, 8008, 8009, 8080, 8081, 8121,
        8443, 8600, 8700, 8888, 9000, 9999, 10000, 25123, 52020, 52021,
        52022, 52023, 52024, 52025, 53000, 56789, 57395,
        6466, 6467,
        51010, 51020, 51030, 51040, 51050, 51060
    )

    data class Result(val port: Int, val detail: String)

    fun scan(host: String, onFinished: (List<Result>) -> Unit) {
        executor.execute {
            val results = mutableListOf<Result>()

            // Keep the first scanner simple and reliable: probe each port from
            // one background worker. This avoids Kotlin/Java Future generic
            // inference problems and is fast enough for this small port list.
            for (port in ports.distinct()) {
                try {
                    probe(host, port)?.let { results.add(it) }
                } catch (_: Exception) {
                }
            }

            results.sortBy { it.port }
            onFinished(results)
        }
    }

    private fun probe(host: String, port: Int): Result? {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 350)
                socket.soTimeout = 700
                val detail = if (port == 80 || port == 8000 || port == 8001 ||
                    port == 8002 || port == 8080 || port == 8081 || port == 8121 ||
                    port == 8888 || port == 9000 || port == 9999 || port == 25123 ||
                    port == 53000 || port == 56789) {
                    tryHttpHead(socket, host, port)
                } else {
                    "TCP açık"
                }
                Result(port, detail)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun tryHttpHead(socket: Socket, host: String, port: Int): String {
        return try {
            val request = "HEAD / HTTP/1.1\r\nHost: $host\r\nConnection: close\r\n\r\n"
            socket.getOutputStream().write(request.toByteArray(StandardCharsets.US_ASCII))
            socket.getOutputStream().flush()
            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8))
            val first = reader.readLine()?.trim().orEmpty()
            if (first.isBlank()) "TCP açık" else first.take(180)
        } catch (_: Exception) {
            "TCP açık (HTTP yanıtı yok)"
        }
    }
}
