package com.wanboremote.test2

import android.content.Context
import android.graphics.*
import android.graphics.drawable.*
import android.view.MotionEvent
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.min

class WanboRemoteView(context: Context) : View(context) {
    enum class Action {
        PAIR, POWER, INPUT, APPS, ASSIST, SETTINGS,
        UP, DOWN, LEFT, RIGHT, OK, BACK, PROJECTOR, HOME,
        VOL_UP, VOL_DOWN, MUTE, FOCUS_PLUS, FOCUS_MINUS,
        YOUTUBE, NETFLIX, PRIME, DISNEY, HDMI1, HDMI2, USB
    }

    var onAction: ((Action) -> Unit)? = null
    var deviceName: String = "--"
        set(value) { field = value; invalidate() }
    var connected: Boolean = false
        set(value) { field = value; invalidate() }
    var paired: Boolean = false
        set(value) { field = value; invalidate() }

    private val bitmap = BitmapFactory.decodeResource(resources, resources.getIdentifier("wanbo_remote_background", "drawable", context.packageName))
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val overlay = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blue = Color.rgb(24, 151, 255)
    private val white = Color.WHITE

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(2, 7, 12))

        // Android 15+ uses edge-to-edge by default. Keep the complete remote
        // between the system status/navigation bars so the top title and bottom
        // input selector are never hidden behind system UI.
        val insets = ViewCompat.getRootWindowInsets(this)
        val topInset = insets?.getInsets(WindowInsetsCompat.Type.systemBars())?.top ?: 0
        val bottomInset = insets?.getInsets(WindowInsetsCompat.Type.systemBars())?.bottom ?: 0
        val availableHeight = (height - topInset - bottomInset).coerceAtLeast(1)
        val scale = min(
            width.toFloat() / bitmap.width.toFloat(),
            availableHeight.toFloat() / bitmap.height.toFloat()
        )
        val contentWidth = bitmap.width * scale
        val contentHeight = bitmap.height * scale
        val originX = (width - contentWidth) / 2f
        val originY = topInset.toFloat()
        canvas.save()
        canvas.translate(originX, originY)
        val dst = RectF(0f, 0f, contentWidth, contentHeight)
        canvas.drawBitmap(bitmap, null, dst, paint)

        // Cihaz adı ve bağlantı durumu doğrudan arka plan üzerinde gösterilir;
        // arkadaki panel şeffaftır.
        val sx = scale

        // Cihaz adı ayrı satırda; bağlantı noktası yalnızca durum metninin önünde.
        overlay.color = Color.WHITE
        overlay.textSize = 20f * sx
        overlay.typeface = Typeface.create("sans", Typeface.NORMAL)
        canvas.drawText(if (deviceName.isBlank()) "--" else deviceName.take(18), 85f * sx, 94f * sx, overlay)

        overlay.color = if (connected) Color.rgb(0, 235, 105) else Color.rgb(220, 38, 38)
        canvas.drawCircle(61f * sx, 118f * sx, 9f * sx, overlay)
        overlay.color = if (connected) Color.WHITE else Color.rgb(165, 180, 195)
        overlay.textSize = 20f * sx
        canvas.drawText(if (connected) "Bağlı" else "Bağlı değil", 85f * sx, 124f * sx, overlay)

        // Pair button: use the exact same circle position/size as the + button,
        // but replace the + with a clear X so the action is unmistakably "unpair".
        if (paired) {
            val cx = 611f * sx
            val cy = 76f * sx
            overlay.style = Paint.Style.FILL
            overlay.color = Color.rgb(5, 17, 27)
            canvas.drawCircle(cx, cy, 45f * sx, overlay)
            overlay.style = Paint.Style.STROKE
            overlay.strokeWidth = 1.8f * sx
            overlay.color = Color.rgb(32, 157, 255)
            canvas.drawCircle(cx, cy, 45f * sx, overlay)

            // Clear red X inside a white/red ring.
            overlay.color = Color.rgb(255, 74, 74)
            overlay.strokeWidth = 6f * sx
            overlay.strokeCap = Paint.Cap.ROUND
            canvas.drawLine(cx - 15f*sx, cy - 15f*sx, cx + 15f*sx, cy + 15f*sx, overlay)
            canvas.drawLine(cx + 15f*sx, cy - 15f*sx, cx - 15f*sx, cy + 15f*sx, overlay)
            overlay.strokeCap = Paint.Cap.BUTT
            overlay.style = Paint.Style.FILL
        }
        canvas.restore()
    }

    private fun hit(x: Float, y: Float, l: Int, t: Int, r: Int, b: Int): Boolean =
        x >= l && x <= r && y >= t && y <= b

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val insets = ViewCompat.getRootWindowInsets(this)
        val topInset = insets?.getInsets(WindowInsetsCompat.Type.systemBars())?.top ?: 0
        val bottomInset = insets?.getInsets(WindowInsetsCompat.Type.systemBars())?.bottom ?: 0
        val availableHeight = (height - topInset - bottomInset).coerceAtLeast(1)
        val sx = min(
            width.toFloat() / bitmap.width.toFloat(),
            availableHeight.toFloat() / bitmap.height.toFloat()
        )
        val contentWidth = bitmap.width * sx
        val originX = (width - contentWidth) / 2f
        val x = (event.x - originX) / sx
        val stretchedY = (event.y - topInset) / sx

        // Siyah ayırıcı şeritler kaldırıldığı için dokunmayı eski referans
        // koordinatlarına geri taşıyoruz.
        val y = when {
            stretchedY < 600f -> stretchedY
            stretchedY < 775f -> stretchedY + 45f
            stretchedY < 990f -> stretchedY + 80f
            stretchedY < 1150f -> stretchedY + 110f
            else -> stretchedY + 140f
        }

        val a = when {
            hit(x,y,545,25,675,160) -> Action.PAIR
            hit(x,y,25,180,150,315) -> Action.POWER
            hit(x,y,155,180,275,315) -> Action.INPUT
            hit(x,y,275,180,405,315) -> Action.APPS
            hit(x,y,410,180,535,315) -> Action.ASSIST
            hit(x,y,535,180,675,315) -> Action.SETTINGS
            hit(x,y,245,315,445,445) -> Action.UP
            hit(x,y,150,400,285,585) -> Action.LEFT
            hit(x,y,275,425,420,575) -> Action.OK
            hit(x,y,410,400,545,585) -> Action.RIGHT
            hit(x,y,245,560,445,690) -> Action.DOWN
            hit(x,y,115,640,250,785) -> Action.BACK
            hit(x,y,270,650,420,805) -> Action.PROJECTOR
            hit(x,y,445,640,585,785) -> Action.HOME
            hit(x,y,35,775,180,995) -> if (y < 890) Action.VOL_UP else Action.VOL_DOWN
            hit(x,y,270,805,425,970) -> Action.MUTE
            hit(x,y,505,775,660,995) -> if (y < 890) Action.FOCUS_PLUS else Action.FOCUS_MINUS
            hit(x,y,55,995,340,1070) -> Action.YOUTUBE
            hit(x,y,345,995,650,1070) -> Action.NETFLIX
            hit(x,y,55,1070,340,1145) -> Action.PRIME
            hit(x,y,345,1070,650,1145) -> Action.DISNEY
            hit(x,y,25,1155,240,1315) -> Action.HDMI1
            hit(x,y,240,1155,455,1315) -> Action.HDMI2
            hit(x,y,455,1155,675,1315) -> Action.USB
            else -> null
        }
        if (a != null) onAction?.invoke(a)
        performClick()
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
