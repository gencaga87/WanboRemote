package com.wanboremote.test2

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.text.InputType
import android.view.View
import android.widget.*
import java.net.InetAddress
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var nsd: NsdManager
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var pairButton: Button
    private lateinit var connectButton: Button
    private lateinit var remotePanel: LinearLayout
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var discoveredHost: InetAddress? = null
    private var discoveredPort: Int = 6467
    private var discoveredName: String = "Wanbo Mozart 1 Pro"
    private val executor = Executors.newSingleThreadExecutor()
    private var remote: RemoteControl? = null

    companion object { private const val SERVICE_TYPE = "_androidtvremote2._tcp." }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        nsd = getSystemService(NSD_SERVICE) as NsdManager
        status = findViewById(R.id.statusText)
        result = findViewById(R.id.resultText)
        pairButton = findViewById(R.id.pairButton)
        connectButton = findViewById(R.id.connectButton)
        remotePanel = findViewById(R.id.remotePanel)

        findViewById<Button>(R.id.scanButton).setOnClickListener { startDiscovery() }
        pairButton.setOnClickListener { startPairing() }
        connectButton.setOnClickListener { connectRemote() }

        bindRemoteButtons()
        startDiscovery()
    }

    private fun bindRemoteButtons() {
        findViewById<Button>(R.id.upButton).setOnClickListener { key(RemoteControl.KEY_DPAD_UP) }
        findViewById<Button>(R.id.downButton).setOnClickListener { key(RemoteControl.KEY_DPAD_DOWN) }
        findViewById<Button>(R.id.leftButton).setOnClickListener { key(RemoteControl.KEY_DPAD_LEFT) }
        findViewById<Button>(R.id.rightButton).setOnClickListener { key(RemoteControl.KEY_DPAD_RIGHT) }
        findViewById<Button>(R.id.okButton).setOnClickListener { key(RemoteControl.KEY_DPAD_CENTER) }
        findViewById<Button>(R.id.backButton).setOnClickListener { key(RemoteControl.KEY_BACK) }
        findViewById<Button>(R.id.homeButton).setOnClickListener { key(RemoteControl.KEY_HOME) }
        findViewById<Button>(R.id.volumeDownButton).setOnClickListener { key(RemoteControl.KEY_VOLUME_DOWN) }
        findViewById<Button>(R.id.volumeUpButton).setOnClickListener { key(RemoteControl.KEY_VOLUME_UP) }
        findViewById<Button>(R.id.muteButton).setOnClickListener { key(RemoteControl.KEY_MUTE) }
        findViewById<Button>(R.id.powerButton).setOnClickListener { key(RemoteControl.KEY_POWER) }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { key(RemoteControl.KEY_SETTINGS) }
        findViewById<Button>(R.id.menuButton).setOnClickListener { key(RemoteControl.KEY_MENU) }
        findViewById<Button>(R.id.assistButton).setOnClickListener { key(RemoteControl.KEY_ASSIST) }
        findViewById<Button>(R.id.inputButton).setOnClickListener { key(RemoteControl.KEY_TV_INPUT) }
        findViewById<Button>(R.id.playPauseButton).setOnClickListener { key(RemoteControl.KEY_MEDIA_PLAY_PAUSE) }
    }

    private fun key(code: Int) {
        if (remote?.isConnected() == true) {
            remote?.sendKey(code)
        } else {
            Toast.makeText(this, "Önce KUMANDAYA BAĞLAN yapın.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startDiscovery() {
        stopDiscovery()
        pairButton.visibility = View.GONE
        connectButton.visibility = View.GONE
        remotePanel.visibility = View.GONE
        discoveredHost = null
        status.text = "Yerel ağda Mozart 1 Pro aranıyor..."
        result.text = "Aranıyor..."
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) { status.text = "Keşif başladı..." }
            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                nsd.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                        runOnUiThread { status.text = "Cihaz bulundu fakat ayrıntıları alınamadı." }
                    }
                    override fun onServiceResolved(info: NsdServiceInfo) {
                        discoveredHost = info.host
                        discoveredPort = 6467
                        discoveredName = info.serviceName ?: "Wanbo Mozart 1 Pro"
                        val ip = info.host?.hostAddress ?: "IP alınamadı"
                        runOnUiThread {
                            status.text = "Cihaz bulundu!"
                            result.text = "📺 $discoveredName\n\nIP: $ip\nPairing portu: 6467\nRemote portu: 6466\nServis: ${info.serviceType}"
                            pairButton.visibility = View.VISIBLE
                            connectButton.visibility = View.VISIBLE
                        }
                    }
                })
            }
            override fun onServiceLost(serviceInfo: NsdServiceInfo) { runOnUiThread { status.text = "Cihaz ağdan ayrıldı." } }
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { nsd.stopServiceDiscovery(this); runOnUiThread { status.text = "Keşif başlatılamadı." } }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) { nsd.stopServiceDiscovery(this) }
        }
        discoveryListener = listener
        nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    private fun startPairing() {
        val host = discoveredHost ?: run { status.text = "Önce cihazı bulun."; return }
        pairButton.isEnabled = false
        status.text = "Güvenli bağlantı kuruluyor..."
        executor.execute {
            try {
                val identity = ClientIdentity.loadOrCreate(this)
                val pairing = TlsPairing(identity)
                pairing.pair(host.hostAddress ?: error("IP yok"), discoveredPort) {
                    val holder = arrayOfNulls<String>(1)
                    runOnUiThread {
                        val input = EditText(this).apply {
                            hint = "Örn. A1B2C3"
                            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                        }
                        AlertDialog.Builder(this)
                            .setTitle("Projektör PIN'i")
                            .setMessage("Projektör ekranında görünen 6 haneli HEX kodu girin.")
                            .setView(input)
                            .setCancelable(false)
                            .setPositiveButton("Eşleştir") { _, _ -> holder[0] = input.text.toString() }
                            .setNegativeButton("İptal") { _, _ -> holder[0] = "" }
                            .show()
                    }
                    while (holder[0] == null) Thread.sleep(100)
                    holder[0]!!
                }
                runOnUiThread {
                    status.text = "🎉 Eşleştirme başarılı!"
                    result.text = "📺 $discoveredName\n\nGüvenli eşleştirme tamamlandı.\n\nŞimdi kumanda kanalına bağlanıyoruz..."
                    pairButton.isEnabled = true
                    pairButton.text = "EŞLEŞTİRİLDİ"
                }
                connectRemoteInternal(host.hostAddress ?: error("IP yok"))
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Eşleştirme başarısız."
                    result.text = "Hata: ${e.message ?: e.javaClass.simpleName}\n\nProjektörde PIN ekranı çıkmadıysa tekrar deneyin."
                    pairButton.isEnabled = true
                }
            }
        }
    }

    private fun connectRemote() {
        val host = discoveredHost ?: run { status.text = "Önce cihazı bulun."; return }
        connectRemoteInternal(host.hostAddress ?: error("IP yok"))
    }

    private fun connectRemoteInternal(host: String) {
        runOnUiThread {
            connectButton.isEnabled = false
            status.text = "Kumanda bağlantısı kuruluyor..."
            result.text = "📺 $discoveredName\n\nAndroid TV Remote v2 kumanda kanalı (6466) açılıyor..."
        }
        executor.execute {
            try {
                val identity = ClientIdentity.loadOrCreate(this)
                val controller = RemoteControl(identity)
                remote?.close()
                remote = controller
                controller.connect(host,
                    onReady = {
                        runOnUiThread {
                            status.text = "🎮 KUMANDA BAĞLANDI!"
                            result.text = "📺 $discoveredName\n\nGerçek kumanda bağlantısı hazır. Aşağıdaki tuşlardan test edebilirsiniz."
                            connectButton.isEnabled = true
                            connectButton.text = "KUMANDA BAĞLANDI"
                            remotePanel.visibility = View.VISIBLE
                        }
                    },
                    onError = { message ->
                        runOnUiThread {
                            status.text = "Kumanda bağlantısı başarısız."
                            result.text = "Hata: $message\n\nProjektör açık ve aynı Wi-Fi ağında mı?"
                            connectButton.isEnabled = true
                            remotePanel.visibility = View.GONE
                        }
                    }
                )
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Kumanda bağlantısı başarısız."
                    result.text = "Hata: ${e.message ?: e.javaClass.simpleName}"
                    connectButton.isEnabled = true
                }
            }
        }
    }

    private fun stopDiscovery() {
        discoveryListener?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        discoveryListener = null
    }

    override fun onDestroy() {
        stopDiscovery()
        remote?.close()
        executor.shutdownNow()
        super.onDestroy()
    }
}
