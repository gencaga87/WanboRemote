# Wanbo Remote

Wanbo Mozart 1 Pro için Android TV Remote v2 tabanlı Android kumanda.

Stage 3: güvenli eşleştirilmiş sertifika ile 6466 remote kanalına bağlanır ve DPAD, OK, Home, Back, ses, mute, güç, input ve temel medya tuşlarını gönderir.
