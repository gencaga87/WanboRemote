package com.wanboremote.test2

import java.io.ByteArrayOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.util.concurrent.Executors

/** Stage 37: non-destructive native-port fingerprinting. */
object NativeProtocolScanner {
    private val executor = Executors.newSingleThreadExecutor()

    private val ports = intArrayOf(
        80, 443, 554, 8000, 8001, 8002, 8008, 8009, 8080, 8081, 8121,
        8443, 8600, 8700, 8888, 9000, 9999, 10000, 25123, 52020, 52021,
        52022, 52023, 52024, 52025, 53000, 56789,
        6466, 6467,
        51010, 51020, 51030, 51040, 51050, 51060
    )

    data class Result(val port: Int, val detail: String)

    fun scan(host: String, onFinished: (List<Result>) -> Unit) {
        executor.execute {
            val results = mutableListOf<Result>()
            for (port in ports.distinct()) {
                try { fingerprint(host, port)?.let { results.add(it) } } catch (_: Exception) { }
            }
            results.sortBy { it.port }
            onFinished(results)
        }
    }

    private fun fingerprint(host: String, port: Int): Result? =
        if (port == 443 || port == 8443) fingerprintTls(host, port) else fingerprintTcp(host, port)

    private fun fingerprintTcp(host: String, port: Int): Result? {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 700)
                socket.soTimeout = 1200
                val first = readInitial(socket.getInputStream(), 900)
                val detail = if (first.isNotEmpty()) {
                    "TCP açık; pasif RX=${first.size}B; ${describeBytes(first)}"
                } else if (isLikelyHttpPort(port)) {
                    val http = safeHttpHead(socket, host)
                    if (http != null) "TCP açık; pasif RX yok; HTTP=$http" else "TCP açık; pasif RX yok"
                } else {
                    "TCP açık; pasif RX yok"
                }
                Result(port, detail)
            }
        } catch (_: Exception) { null }
    }

    private fun isLikelyHttpPort(port: Int): Boolean = port in setOf(
        80, 8000, 8001, 8002, 8008, 8009, 8080, 8081, 8121, 8600, 8700,
        8888, 9000, 9999, 10000, 25123, 53000, 56789
    )

    private fun safeHttpHead(socket: Socket, host: String): String? {
        return try {
            val request = "HEAD / HTTP/1.1\r\nHost: $host\r\nConnection: close\r\nUser-Agent: WanboRemote-Stage37\r\n\r\n"
            socket.getOutputStream().write(request.toByteArray(StandardCharsets.US_ASCII))
            socket.getOutputStream().flush()
            val buffer = ByteArray(768)
            val n = socket.getInputStream().read(buffer)
            if (n <= 0) return null
            val raw = buffer.copyOf(n).toString(StandardCharsets.UTF_8)
            val lines = raw.split("\r\n", "\n").filter { it.isNotBlank() }.take(8)
            if (lines.isEmpty()) null else lines.joinToString(" | ").take(600)
        } catch (_: Exception) { null }
    }

    private fun readInitial(input: java.io.InputStream, waitMs: Long): ByteArray {
        val deadline = android.os.SystemClock.elapsedRealtime() + waitMs
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(1024)
        while (android.os.SystemClock.elapsedRealtime() < deadline && out.size() < 2048) {
            val available = try { input.available() } catch (_: Exception) { 0 }
            if (available > 0) {
                val n = input.read(buffer, 0, minOf(buffer.size, available))
                if (n > 0) out.write(buffer, 0, n)
            } else {
                try { Thread.sleep(50) } catch (_: InterruptedException) { break }
            }
        }
        return out.toByteArray()
    }

    private fun fingerprintTls(host: String, port: Int): Result? {
        return try {
            val trustAll = object : X509TrustManager {
                override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) = Unit
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) = Unit
            }
            val context = SSLContext.getInstance("TLS")
            context.init(null, arrayOf<TrustManager>(trustAll), SecureRandom())
            val socket = context.socketFactory.createSocket() as javax.net.ssl.SSLSocket
            socket.use {
                it.connect(InetSocketAddress(host, port), 900)
                it.soTimeout = 1500
                try {
                    it.startHandshake()
                    val session = it.session
                    val cert = session.peerCertificates.firstOrNull() as? X509Certificate
                    val subject = cert?.subjectX500Principal?.name ?: "?"
                    val issuer = cert?.issuerX500Principal?.name ?: "?"
                    Result(port, "TLS açık; protocol=${session.protocol}; cipher=${session.cipherSuite}; subject=${subject.take(180)}; issuer=${issuer.take(180)}")
                } catch (e: Exception) {
                    Result(port, "TCP açık; TLS handshake başarısız: ${e.javaClass.simpleName}: ${(e.message ?: "").take(180)}")
                }
            }
        } catch (_: Exception) { null }
    }

    private fun describeBytes(data: ByteArray): String {
        val hex = data.take(96).joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }
        val ascii = data.take(160).map { b ->
            val c = (b.toInt() and 0xFF).toChar()
            if (c in ' '..'~') c else '.'
        }.joinToString("")
        return "hex=$hex; ascii=${ascii.take(160)}"
    }
}
