package com.wanboremote.test2

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ProtocolLog {
    private const val MAX = 160
    private val lock = Any()
    private val entries = ArrayDeque<String>()
    private val format = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun add(message: String) {
        synchronized(lock) {
            entries.addLast("${format.format(Date())}  $message")
            while (entries.size > MAX) entries.removeFirst()
        }
    }

    fun clear() {
        synchronized(lock) { entries.clear() }
    }

    fun dump(): String = synchronized(lock) {
        if (entries.isEmpty()) "(Henüz protokol olayı yok)" else entries.joinToString("\n")
    }
}
