package com.wanboremote.test2

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.*
import java.net.InetAddress
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var screen: WanboRemoteView
    private lateinit var nsd: NsdManager
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var discoveredHost: InetAddress? = null
    private var discoveredPort: Int = 6467
    private var discoveredName: String = "--"
    private val executor = Executors.newSingleThreadExecutor()
    private var remote: RemoteControl? = null
    private var pairingDialog: Dialog? = null

    private val prefs by lazy { getSharedPreferences("wanbo_state", Context.MODE_PRIVATE) }
    private val isPaired: Boolean get() = prefs.getBoolean("paired", false)
    companion object { private const val SERVICE_TYPE = "_androidtvremote2._tcp." }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(3, 7, 12)
        window.navigationBarColor = Color.rgb(3, 7, 12)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(true)
        }
        screen = WanboRemoteView(this)
        setContentView(screen)
        nsd = getSystemService(NSD_SERVICE) as NsdManager
        screen.paired = isPaired
        screen.onAction = { handleAction(it) }
        startDiscovery()
    }

    private fun handleAction(a: WanboRemoteView.Action) {
        when (a) {
            WanboRemoteView.Action.PAIR -> if (isPaired) confirmUnpair() else showPairDialog()
            WanboRemoteView.Action.POWER -> key(RemoteControl.KEY_POWER)
            WanboRemoteView.Action.INPUT -> key(RemoteControl.KEY_TV_INPUT)
            WanboRemoteView.Action.APPS -> key(RemoteControl.KEY_MENU)
            WanboRemoteView.Action.ASSIST -> key(RemoteControl.KEY_VOICE_ASSIST)
            WanboRemoteView.Action.SETTINGS -> key(RemoteControl.KEY_SETTINGS)
            WanboRemoteView.Action.UP -> key(RemoteControl.KEY_DPAD_UP)
            WanboRemoteView.Action.DOWN -> key(RemoteControl.KEY_DPAD_DOWN)
            WanboRemoteView.Action.LEFT -> key(RemoteControl.KEY_DPAD_LEFT)
            WanboRemoteView.Action.RIGHT -> key(RemoteControl.KEY_DPAD_RIGHT)
            WanboRemoteView.Action.OK -> key(RemoteControl.KEY_DPAD_CENTER)
            WanboRemoteView.Action.BACK -> key(RemoteControl.KEY_BACK)
            WanboRemoteView.Action.HOME -> key(RemoteControl.KEY_HOME)
            WanboRemoteView.Action.PROJECTOR -> Toast.makeText(this, "Projektör tuşu için Bluetooth/IR aşaması gerekiyor.", Toast.LENGTH_SHORT).show()
            WanboRemoteView.Action.VOL_UP -> key(RemoteControl.KEY_VOLUME_UP)
            WanboRemoteView.Action.VOL_DOWN -> key(RemoteControl.KEY_VOLUME_DOWN)
            WanboRemoteView.Action.MUTE -> key(RemoteControl.KEY_MUTE)
            WanboRemoteView.Action.FOCUS_PLUS -> key(RemoteControl.KEY_ZOOM_IN)
            WanboRemoteView.Action.FOCUS_MINUS -> key(RemoteControl.KEY_ZOOM_OUT)
            WanboRemoteView.Action.HDMI1 -> key(RemoteControl.KEY_TV_INPUT_HDMI_1)
            WanboRemoteView.Action.HDMI2 -> key(RemoteControl.KEY_TV_INPUT_HDMI_2)
            WanboRemoteView.Action.USB -> key(RemoteControl.KEY_TV_INPUT)
            WanboRemoteView.Action.YOUTUBE -> Toast.makeText(this, "YouTube kısayolu Wi‑Fi kanalında eklenebilir.", Toast.LENGTH_SHORT).show()
            WanboRemoteView.Action.NETFLIX -> Toast.makeText(this, "Netflix kısayolu Wi‑Fi kanalında eklenebilir.", Toast.LENGTH_SHORT).show()
            WanboRemoteView.Action.PRIME -> Toast.makeText(this, "Prime Video kısayolu Wi‑Fi kanalında eklenebilir.", Toast.LENGTH_SHORT).show()
            WanboRemoteView.Action.DISNEY -> Toast.makeText(this, "Disney+ kısayolu Wi‑Fi kanalında eklenebilir.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun key(code: Int) {
        if (remote?.isConnected() == true) remote?.sendKey(code)
        else Toast.makeText(this, "Önce sağ üstteki + ile cihazı eşleştirin.", Toast.LENGTH_SHORT).show()
    }

    private fun startDiscovery() {
        stopDiscovery()
        discoveredHost = null
        screen.connected = false
        screen.deviceName = "--"
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                nsd.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {}
                    override fun onServiceResolved(info: NsdServiceInfo) {
                        discoveredHost = info.host
                        discoveredPort = info.port
                        discoveredName = info.serviceName?.takeIf { it.isNotBlank() } ?: "Android TV"
                        runOnUiThread {
                            if (screen.connected) screen.deviceName = discoveredName
                            if (isPaired && remote?.isConnected() != true) connectRemoteInternal(info.host.hostAddress ?: return@runOnUiThread)
                        }
                    }
                })
            }
            override fun onServiceLost(serviceInfo: NsdServiceInfo) { runOnUiThread { if (!screen.connected) screen.deviceName = "--" } }
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { try { nsd.stopServiceDiscovery(this) } catch (_: Exception) {} }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) { try { nsd.stopServiceDiscovery(this) } catch (_: Exception) {} }
        }
        discoveryListener = listener
        nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    private fun showPairDialog() {
        if (pairingDialog?.isShowing == true) return

        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            background = GradientDrawable().apply {
                setColor(Color.rgb(7, 16, 25))
                cornerRadius = 28f
                setStroke(2, Color.rgb(30, 148, 255))
            }
        }

        val titleRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "Cihaz Eşleştir"
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setOnClickListener { dialog.dismiss() }
        }
        titleRow.addView(title, LinearLayout.LayoutParams(0, 48, 1f))
        titleRow.addView(close, LinearLayout.LayoutParams(52, 48))
        root.addView(titleRow)

        val photo = ImageView(this).apply {
            setImageResource(R.drawable.projector_photo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        root.addView(photo, LinearLayout.LayoutParams(-1, 72))

        val info = TextView(this).apply {
            text = "Wanbo projektör aranıyor..."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(150, 180, 210))
        }
        root.addView(info, LinearLayout.LayoutParams(-1, 32))

        fun deviceRow(name: String, address: String, enabled: Boolean, primary: Boolean, action: (() -> Unit)? = null): LinearLayout {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 5, 8, 5)
                background = GradientDrawable().apply {
                    setColor(Color.rgb(9, 25, 39))
                    cornerRadius = 18f
                    setStroke(2, if (primary) Color.rgb(20, 145, 255) else Color.rgb(48, 65, 84))
                }
            }

            val icon = ImageView(this).apply {
                setImageResource(R.drawable.projector_photo)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }
            row.addView(icon, LinearLayout.LayoutParams(72, 50))

            val text = TextView(this).apply {
                this.text = "$name\n$address"
                textSize = 13f
                setTextColor(if (enabled) Color.WHITE else Color.rgb(130, 145, 160))
                setPadding(5, 0, 5, 0)
            }
            row.addView(text, LinearLayout.LayoutParams(0, 52, 1f))

            val pair = Button(this).apply {
                this.text = "Eşleştir"
                isEnabled = enabled
                setTextSize(12f)
                if (enabled) setOnClickListener { action?.invoke() }
            }
            row.addView(pair, LinearLayout.LayoutParams(92, 46))
            return row
        }

        val actualName = if (screen.connected) discoveredName else "--"
        val actualIp = discoveredHost?.hostAddress ?: "Cihaz aranıyor..."

        root.addView(
            deviceRow(actualName, actualIp, discoveredHost != null, true) {
                dialog.dismiss()
                startPairing()
            },
            LinearLayout.LayoutParams(-1, 62)
        )

        root.addView(
            deviceRow("Salon Projektör", "Ağda aranıyor...", false, false),
            LinearLayout.LayoutParams(-1, 62).apply { topMargin = 7 }
        )

        root.addView(
            deviceRow("Wanbo Projektör", "Ağda aranıyor...", false, false),
            LinearLayout.LayoutParams(-1, 62).apply { topMargin = 7 }
        )

        val cancel = Button(this).apply {
            text = "İptal"
            setOnClickListener { dialog.dismiss() }
        }
        root.addView(cancel, LinearLayout.LayoutParams(-1, 50).apply { topMargin = 8 })

        dialog.setContentView(root)
        dialog.setCancelable(true)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pairingDialog = dialog

        dialog.setOnShowListener {
            dialog.window?.setLayout(
                (resources.displayMetrics.widthPixels * 0.92f).toInt(),
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }
        dialog.show()
    }

    private fun startPairing() {
        val host = discoveredHost ?: run { Toast.makeText(this,"Wanbo henüz bulunamadı.",Toast.LENGTH_SHORT).show(); return }
        executor.execute {
            try {
                val identity = ClientIdentity.loadOrCreate(this)
                val pairing = TlsPairing(identity)
                pairing.pair(host.hostAddress ?: error("IP yok"), discoveredPort) {
                    val holder = arrayOfNulls<String>(1)
                    runOnUiThread {
                        val input = EditText(this).apply { hint="Örn. A1B2C3"; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS; setSingleLine(true) }
                        android.app.AlertDialog.Builder(this).setTitle("Projektör PIN'i").setMessage("Projektör ekranındaki 6 haneli HEX kodu girin.").setView(input).setCancelable(false).setPositiveButton("Eşleştir") { _,_ -> holder[0]=input.text.toString() }.setNegativeButton("İptal") { _,_ -> holder[0]="" }.show()
                    }
                    while(holder[0]==null) Thread.sleep(100)
                    holder[0]!!
                }
                prefs.edit().putBoolean("paired",true).apply()
                runOnUiThread { screen.paired=true; screen.connected=false }
                connectRemoteInternal(host.hostAddress ?: error("IP yok"))
            } catch(e:Exception) { runOnUiThread { screen.connected=false; Toast.makeText(this,"Eşleştirme başarısız: ${e.message}",Toast.LENGTH_LONG).show() } }
        }
    }

    private fun connectRemoteInternal(host: String) {
        executor.execute {
            try {
                val identity=ClientIdentity.loadOrCreate(this)
                val controller=RemoteControl(identity)
                remote?.close(); remote=controller
                controller.connect(host,
                    onReady={ runOnUiThread { screen.connected=true; screen.deviceName=discoveredName } },
                    onError={ _ -> runOnUiThread { screen.connected=false; screen.deviceName="--" } })
            } catch(_:Exception) { runOnUiThread { screen.connected=false; screen.deviceName="--" } }
        }
    }

    private fun confirmUnpair() {
        android.app.AlertDialog.Builder(this).setTitle("Eşleştirmeyi iptal et?").setMessage("Bu telefondaki eşleştirme durumunu kaldır.").setNegativeButton("Vazgeç",null).setPositiveButton("İptal Et") { _,_ -> prefs.edit().putBoolean("paired",false).apply(); remote?.close(); remote=null; screen.paired=false; screen.connected=false; screen.deviceName="--" }.show()
    }

    private fun stopDiscovery() { discoveryListener?.let { try { nsd.stopServiceDiscovery(it) } catch(_:Exception){} }; discoveryListener=null }
    override fun onDestroy(){ stopDiscovery(); remote?.close(); executor.shutdownNow(); super.onDestroy() }
}
