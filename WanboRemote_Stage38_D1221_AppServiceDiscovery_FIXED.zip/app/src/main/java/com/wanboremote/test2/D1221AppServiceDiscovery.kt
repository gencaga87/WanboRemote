package com.wanboremote.test2

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import java.io.File
import java.util.zip.ZipFile

object D1221AppServiceDiscovery {
    private val keywords = listOf(
        "wanbo", "d1221", "sdmc", "projector", "focus", "keystone",
        "hdmi", "power", "remote", "ir", "cast", "settings", "calibration"
    )

    data class Report(val text: String)

    fun run(context: Context): Report {
        val pm = context.packageManager
        val flags = PackageManager.GET_ACTIVITIES or
                PackageManager.GET_SERVICES or
                PackageManager.GET_RECEIVERS or
                PackageManager.GET_PROVIDERS or
                PackageManager.GET_META_DATA

        val packages = try {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(flags)
        } catch (e: Exception) {
            return Report("PackageManager hatası: ${e.javaClass.simpleName}: ${e.message}")
        }

        val own = context.packageName
        val candidates = packages
            .asSequence()
            .filter { it.packageName != own }
            .map { p -> Candidate(p, score(p, pm)) }
            .filter { it.score > 0 }
            .sortedWith(compareByDescending<Candidate> { it.score }.thenBy { it.pkg.packageName })
            .take(50)
            .toList()

        val out = StringBuilder()
        out.append("D1221 APK / SERVİS KEŞFİ\n\n")
        out.append("Görünen paket sayısı: ").append(packages.size).append('\n')
        out.append("Aday paket sayısı: ").append(candidates.size).append("\n")
        out.append("Anahtarlar: ").append(keywords.joinToString(", ")).append("\n\n")
        out.append("NOT: Bu aşama başka uygulamaları çalıştırmaz ve projektöre komut göndermez.\n")
        out.append("PackageManager görünürlüğü Android 11+ üzerinde kısıtlı olabilir.\n\n")

        if (candidates.isEmpty()) {
            out.append("Anahtar kelimelerle eşleşen paket bulunamadı.\n")
            return Report(out.toString())
        }

        candidates.forEachIndexed { index, c ->
            appendPackage(out, index + 1, c.pkg, c.score, pm)
        }

        return Report(out.toString())
    }

    private data class Candidate(val pkg: PackageInfo, val score: Int)

    private fun score(p: PackageInfo, pm: PackageManager): Int {
        val appInfo = p.applicationInfo ?: return 0
        val label = try { pm.getApplicationLabel(appInfo).toString() } catch (_: Exception) { "" }
        val hay = (p.packageName + " " + label).lowercase()
        var score = 0
        keywords.forEach { k -> if (hay.contains(k)) score += if (k == "d1221" || k == "wanbo" || k == "sdmc") 8 else 2 }
        if (p.services?.isNotEmpty() == true) score += 1
        return score
    }

    private fun appendPackage(out: StringBuilder, rank: Int, p: PackageInfo, score: Int, pm: PackageManager) {
        val appInfo = p.applicationInfo ?: return
        val label = try { pm.getApplicationLabel(appInfo).toString() } catch (_: Exception) { "?" }
        out.append("==== #").append(rank).append(" ").append(p.packageName).append(" ====\n")
        out.append("label=").append(label).append(" score=").append(score).append('\n')
        out.append("version=").append(p.versionName ?: "?").append(" (code=").append(p.longVersionCode).append(")\n")
        out.append("sourceDir=").append(appInfo.sourceDir).append('\n')

        p.services?.let { services ->
            if (services.isNotEmpty()) {
                out.append("SERVICES:\n")
                services.forEach { s ->
                    out.append("  ").append(s.name)
                        .append(" exported=").append(s.exported)
                        .append(" permission=").append(s.permission ?: "-")
                        .append(" process=").append(s.processName ?: "-")
                        .append('\n')
                }
            }
        }
        p.activities?.let { activities ->
            if (activities.isNotEmpty()) {
                out.append("ACTIVITIES (ilk 12):\n")
                activities.take(12).forEach { a ->
                    out.append("  ").append(a.name)
                        .append(" exported=").append(a.exported)
                        .append('\n')
                }
            }
        }
        p.receivers?.let { receivers ->
            if (receivers.isNotEmpty()) {
                out.append("RECEIVERS (ilk 12):\n")
                receivers.take(12).forEach { r ->
                    out.append("  ").append(r.name)
                        .append(" exported=").append(r.exported)
                        .append('\n')
                }
            }
        }

        val hits = scanApk(appInfo.sourceDir)
        if (hits.isNotEmpty()) {
            out.append("APK STRING HITS:\n")
            hits.take(30).forEach { out.append("  ").append(it).append('\n') }
        } else {
            out.append("APK STRING HITS: yok / okunamadı\n")
        }
        out.append('\n')
    }

    private fun scanApk(path: String?): List<String> {
        if (path.isNullOrBlank()) return emptyList()
        val file = File(path)
        if (!file.isFile || !file.canRead()) return emptyList()

        val hits = LinkedHashSet<String>()
        try {
            ZipFile(file).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements() && hits.size < 40) {
                    val e = entries.nextElement()
                    val n = e.name
                    if (e.isDirectory) continue
                    if (!(n.endsWith(".dex") || n.startsWith("assets/") || n.startsWith("res/raw/"))) continue
                    if (e.size > 25L * 1024L * 1024L) continue
                    val bytes = zip.getInputStream(e).use { it.readBytes() }
                    val lower = String(bytes, Charsets.ISO_8859_1).lowercase()
                    keywords.forEach { k ->
                        var start = lower.indexOf(k)
                        var count = 0
                        while (start >= 0 && count < 4 && hits.size < 40) {
                            val from = maxOf(0, start - 90)
                            val to = minOf(bytes.size, start + k.length + 140)
                            val raw = String(bytes, from, to - from, Charsets.ISO_8859_1)
                            val clean = raw.map { ch -> if (ch.code in 32..126) ch else ' ' }.joinToString("")
                                .replace(Regex("\\s+"), " ").trim()
                            hits.add("$n :: $clean")
                            count++
                            start = lower.indexOf(k, start + k.length)
                        }
                    }
                }
            }
        } catch (_: Exception) {
            // Read-only diagnostic: inaccessible APKs are simply skipped.
        }
        return hits.toList()
    }
}
