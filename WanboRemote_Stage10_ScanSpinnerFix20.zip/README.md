# Wanbo Remote Stage 9 Search UX Fix 19

This build keeps the working pairing and remote-control protocol and updates only device discovery UX.

- Opening the device pairing dialog starts a fresh mDNS scan.
- Scan runs for 5 seconds, like a Wi-Fi device search.
- While scanning, the refresh control shows a continuously rotating refresh symbol and is disabled.
- When scanning finishes:
  - 0 devices: `Wanbo projektörü bulunamadı`
  - 1 device: `Wanbo projektörü bulundu`
  - multiple devices: `Wanbo projektörleri bulundu · N cihaz`
- The old duplicate in-list `Wanbo projektör aranıyor... / Cihaz bulunduğunda...` text is removed.
- The refresh control becomes active after the scan.
- Existing mDNS service updates continue to refresh the current projector name while the app is open and paired.


Stage 10 UI Fix 20: Android Wi-Fi Settings style scanning indicator (ring + orbiting dot) and "Yenile" text after scan completes.
