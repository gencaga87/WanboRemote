package com.wanboremote.test2

import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyStore
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class TlsPairing(private val identity: ClientIdentity) {
    data class Result(val serverName: String?)

    fun pair(host: String, port: Int, onPinRequired: (String) -> String): Result {
        val socket = createSocket(host, port)
        socket.soTimeout = 15_000
        socket.startHandshake()
        socket.use {
            val input = it.inputStream
            val output = it.outputStream
            send(output, pairingRequest())
            var frame = Proto.readFrame(input)
            var serverName: String? = null
            while (true) {
                val fields = Proto.parseFields(frame)
                val status = fields.firstOrNull { f -> f.number == 2 }?.let { f -> decodeVarint(f.value) } ?: 0L
                if (status != 200L) throw IllegalStateException("Projektör pairing durumu: $status")
                when {
                    fields.any { it.number == 11 } -> {
                        serverName = Proto.firstString(fields.first { it.number == 11 }.value, 1)
                        send(output, optionsMessage())
                    }
                    fields.any { it.number == 20 } -> send(output, configurationMessage())
                    fields.any { it.number == 31 } -> {
                        val code = onPinRequired("Projektör ekranındaki 6 haneli HEX PIN'i girin.")
                        send(output, secretMessage(code, socket))
                    }
                    fields.any { it.number == 41 } -> return Result(serverName)
                    else -> throw IllegalStateException("Beklenmeyen pairing mesajı: ${fields.map { it.number }}")
                }
                frame = Proto.readFrame(input)
            }
        }
    }

    private fun createSocket(host: String, port: Int): SSLSocket {
        val keyStore = KeyStore.getInstance("PKCS12")
        keyStore.load(null, null)
        keyStore.setKeyEntry("client", identity.keyPair.private, CharArray(0), arrayOf(identity.certificate))
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(keyStore, CharArray(0))

        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) = Unit
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) = Unit
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val context = SSLContext.getInstance("TLS")
        context.init(kmf.keyManagers, arrayOf<TrustManager>(trustAll), SecureRandom())
        val raw = Socket()
        raw.connect(InetSocketAddress(host, port), 10_000)
        return (context.socketFactory.createSocket(raw, host, port, true) as SSLSocket).apply {
            enabledProtocols = arrayOf("TLSv1.3", "TLSv1.2")
        }
    }

    private fun pairingRequest(): ByteArray {
        val inner = Proto.Writer().apply {
            string(1, "atvremote")
            string(2, "mDNSRemote")
        }.toByteArray()
        return outer(10, inner)
    }

    private fun optionsMessage(): ByteArray {
        val encoding = Proto.Writer().apply { varint(1, 3); varint(2, 6) }.toByteArray()
        val outer = Proto.Writer().apply {
            message(1, Proto.Writer().apply { message(1, encoding); varint(3, 1) }.toByteArray())
        }
        // options field 20, inner Options: preferred_role=INPUT(1), input_encodings repeated field 1
        val options = Proto.Writer().apply {
            message(1, encoding)
            varint(3, 1)
        }.toByteArray()
        return outer(20, options)
    }

    private fun configurationMessage(): ByteArray {
        val encoding = Proto.Writer().apply { varint(1, 3); varint(2, 6) }.toByteArray()
        val config = Proto.Writer().apply {
            message(1, encoding)
            varint(2, 1)
        }.toByteArray()
        return outer(30, config)
    }

    private fun secretMessage(codeRaw: String, socket: SSLSocket): ByteArray {
        val code = codeRaw.trim().uppercase()
        if (!Regex("[0-9A-F]{6}").matches(code)) {
            throw IllegalArgumentException("PIN 6 haneli HEX olmalı. Örnek: A1B2C3")
        }

        val clientRsa = identity.certificate.publicKey as java.security.interfaces.RSAPublicKey
        val serverCert = socket.session.peerCertificates.first() as X509Certificate
        val serverRsa = serverCert.publicKey as java.security.interfaces.RSAPublicKey

        // Android TV Remote v2 reference implementation representation:
        // modulus bytes + 0x0001 exponent bytes + server modulus + 0x0001
        // exponent bytes + last 4 hex digits of the PIN.
        // Node's getCertificate()/getPeerCertificate() exposes RSA 65537 as
        // exponent hex "10001"; the reference code prefixes a zero after
        // removing the first two characters, yielding exactly 00 01.
        val clientMod = unsignedBigIntBytes(clientRsa.modulus)
        val serverMod = unsignedBigIntBytes(serverRsa.modulus)
        val exponent = byteArrayOf(0x00, 0x01)
        val pinTail = hexToBytes(code.substring(2))

        val data = concat(
            clientMod,
            exponent,
            serverMod,
            exponent,
            pinTail
        )

        val secret = java.security.MessageDigest.getInstance("SHA-256").digest(data)
        if ((secret[0].toInt() and 0xFF) != code.substring(0, 2).toInt(16)) {
            throw IllegalArgumentException(
                "PIN doğrulanamadı. PIN'i projektörde görünen 6 hane HEX olarak tekrar girin."
            )
        }

        return outer(40, Proto.Writer().apply { bytes(1, secret) }.toByteArray())
    }

    private fun evenLength(value: ByteArray): ByteArray =
        if (value.size % 2 == 0) value else byteArrayOf(0) + value

    private fun concat(vararg parts: ByteArray): ByteArray {
        val total = parts.sumOf { it.size }
        val out = ByteArray(total)
        var offset = 0
        for (part in parts) {
            part.copyInto(out, offset)
            offset += part.size
        }
        return out
    }

    private fun outer(field: Int, nested: ByteArray): ByteArray = Proto.Writer().apply {
        varint(1, 2)
        varint(2, 200)
        message(field, nested)
    }.toByteArray()

    private fun send(output: OutputStream, message: ByteArray) {
        output.write(Proto.frame(message))
        output.flush()
    }

    private fun hexToBytes(s: String): ByteArray {
        val out = ByteArray(s.length / 2)
        for (i in out.indices) out[i] = s.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        return out
    }

    private fun unsignedBigIntBytes(v: java.math.BigInteger): ByteArray {
        // Big-endian unsigned integer bytes, with Java's sign-padding byte
        // removed when present. The protocol supplies its own 0x00
        // separators between modulus and exponent.
        val b = v.toByteArray()
        return if (b.isNotEmpty() && b[0] == 0.toByte()) {
            b.copyOfRange(1, b.size)
        } else {
            b
        }
    }

    private fun decodeVarint(bytes: ByteArray): Long {
        var result = 0L; var shift = 0
        for (b in bytes) { result = result or ((b.toLong() and 0x7F) shl shift); if ((b.toInt() and 0x80) == 0) return result; shift += 7 }
        return result
    }
}
