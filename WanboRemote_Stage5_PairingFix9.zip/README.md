# Wanbo Remote – Stage 4 UI

Wanbo Mozart 1 Pro için tek ekranlı, fiziksel kumanda yerleşimine yakın Android kumanda arayüzü.

- Android TV Remote v2 güvenli eşleştirme korunur.
- Sağ üst `+` cihaz eşleştirme penceresini açar.
- Eşleştirme tamamlanınca `+` eşleştirme iptal düğmesine dönüşür.
- D-pad, Home, Back, ses, mute, Assistant ve Android TV ayarları Wi‑Fi Remote v2 üzerinden çalışır.
- Projektörün fiziksel özel tuşları (odak/projektör kısayolu/fiziksel güç) sonraki Bluetooth/IR aşamasında ele alınacaktır.
- Giriş seçimi paneli: HDMI 1 / Android, HDMI 2 / Harici Cihaz, USB / USB Medya.


Stage 5 PairingFix9: exact upstream PIN hash representation and corrected remote handshake.
