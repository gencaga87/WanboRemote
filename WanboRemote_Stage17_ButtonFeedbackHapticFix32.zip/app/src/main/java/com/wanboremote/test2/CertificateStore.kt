package com.wanboremote.test2

import android.content.Context
import android.util.Base64
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x509.BasicConstraints
import org.bouncycastle.asn1.x509.Extension
import org.bouncycastle.asn1.x509.ExtendedKeyUsage
import org.bouncycastle.asn1.x509.KeyPurposeId
import org.bouncycastle.asn1.x509.KeyUsage
import org.bouncycastle.cert.X509CertificateHolder
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.math.BigInteger
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.Security
import java.security.cert.X509Certificate
import java.util.Date

class ClientIdentity private constructor(
    val keyPair: KeyPair,
    val certificate: X509Certificate
) {
    companion object {
        private const val PREFS = "pairing_identity"
        private const val KEY = "private_key"
        private const val CERT = "certificate"

        fun loadOrCreate(context: Context): ClientIdentity {
            if (Security.getProvider("BC") == null) Security.addProvider(BouncyCastleProvider())
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val keyB64 = prefs.getString(KEY, null)
            val certB64 = prefs.getString(CERT, null)
            if (keyB64 != null && certB64 != null) {
                try {
                    val keyBytes = Base64.decode(keyB64, Base64.DEFAULT)
                    val certBytes = Base64.decode(certB64, Base64.DEFAULT)
                    val kf = java.security.KeyFactory.getInstance("RSA")
                    val privateKey = kf.generatePrivate(java.security.spec.PKCS8EncodedKeySpec(keyBytes))
                    val cf = java.security.cert.CertificateFactory.getInstance("X.509")
                    val cert = cf.generateCertificate(certBytes.inputStream()) as X509Certificate
                    return ClientIdentity(KeyPair(cert.publicKey, privateKey), cert)
                } catch (_: Exception) {
                    prefs.edit().clear().apply()
                }
            }
            val generator = KeyPairGenerator.getInstance("RSA")
            generator.initialize(2048)
            val keyPair = generator.generateKeyPair()
            val cert = createCertificate(keyPair)
            prefs.edit()
                .putString(KEY, Base64.encodeToString(keyPair.private.encoded, Base64.NO_WRAP))
                .putString(CERT, Base64.encodeToString(cert.encoded, Base64.NO_WRAP))
                .apply()
            return ClientIdentity(keyPair, cert)
        }

        private fun createCertificate(keyPair: KeyPair): X509Certificate {
            val now = System.currentTimeMillis()
            val serial = BigInteger(160, java.security.SecureRandom()).abs()
            val subject = X500Name("CN=Wanbo Remote")
            val builder = JcaX509v3CertificateBuilder(
                subject,
                serial,
                Date(now - 60_000),
                Date(now + 3650L * 24 * 60 * 60 * 1000),
                subject,
                keyPair.public
            )
            builder.addExtension(Extension.basicConstraints, true, BasicConstraints(false))
            builder.addExtension(Extension.keyUsage, true, KeyUsage(KeyUsage.digitalSignature or KeyUsage.keyEncipherment))
            builder.addExtension(Extension.extendedKeyUsage, false, ExtendedKeyUsage(KeyPurposeId.id_kp_clientAuth))
            val bcProvider = BouncyCastleProvider()
            val signer = JcaContentSignerBuilder("SHA256withRSA")
                .setProvider(bcProvider)
                .build(keyPair.private)
            val holder: X509CertificateHolder = builder.build(signer)
            return JcaX509CertificateConverter()
                .setProvider(bcProvider)
                .getCertificate(holder)
        }
    }
}
