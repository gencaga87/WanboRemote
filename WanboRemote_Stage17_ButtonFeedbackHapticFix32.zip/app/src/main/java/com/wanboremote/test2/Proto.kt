package com.wanboremote.test2

import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream

object Proto {
    class Writer {
        private val out = ByteArrayOutputStream()
        fun varint(field: Int, value: Long) {
            tag(field, 0)
            writeVarint(value)
        }
        fun string(field: Int, value: String) = bytes(field, value.toByteArray(Charsets.UTF_8))
        fun bytes(field: Int, value: ByteArray) {
            tag(field, 2)
            writeVarint(value.size.toLong())
            out.write(value)
        }
        fun message(field: Int, value: ByteArray) = bytes(field, value)
        private fun tag(field: Int, wire: Int) = writeVarint(((field shl 3) or wire).toLong())
        private fun writeVarint(v0: Long) {
            var v = v0
            while (true) {
                if ((v and 0x7FL.inv()) == 0L) { out.write(v.toInt()); return }
                out.write(((v and 0x7F) or 0x80).toInt())
                v = v ushr 7
            }
        }
        fun toByteArray(): ByteArray = out.toByteArray()
    }

    data class Field(val number: Int, val wire: Int, val value: ByteArray)

    fun parseFields(data: ByteArray): List<Field> {
        val r = Reader(data)
        val fields = mutableListOf<Field>()
        while (!r.eof()) {
            val tag = r.varint().toInt()
            val number = tag ushr 3
            val wire = tag and 7
            val value = when (wire) {
                0 -> encodeVarint(r.varint())
                2 -> r.bytes()
                else -> throw IllegalArgumentException("Unsupported protobuf wire type $wire")
            }
            fields += Field(number, wire, value)
        }
        return fields
    }

    fun firstBytes(data: ByteArray, field: Int): ByteArray? = parseFields(data).firstOrNull { it.number == field }?.value
    fun firstString(data: ByteArray, field: Int): String? = firstBytes(data, field)?.toString(Charsets.UTF_8)
    fun firstVarint(data: ByteArray, field: Int): Long? = parseFields(data).firstOrNull { it.number == field }?.let { decodeVarint(it.value) }

    fun frame(message: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        writeVarint(out, message.size.toLong())
        out.write(message)
        return out.toByteArray()
    }

    fun readFrame(input: InputStream): ByteArray {
        val len = readVarint(input).toInt()
        if (len < 0 || len > 1024 * 1024) throw IllegalArgumentException("Invalid protobuf frame length: $len")
        val data = ByteArray(len)
        var off = 0
        while (off < len) {
            val n = input.read(data, off, len - off)
            if (n < 0) throw EOFException("Connection closed while reading protobuf frame")
            off += n
        }
        return data
    }


    private fun readVarint(input: InputStream): Long {
        var result = 0L
        var shift = 0
        while (shift <= 63) {
            val b = input.read()
            if (b < 0) throw EOFException("Connection closed while reading varint")
            result = result or ((b.toLong() and 0x7F) shl shift)
            if ((b and 0x80) == 0) return result
            shift += 7
        }
        throw IllegalArgumentException("Invalid varint")
    }

    private fun writeVarint(out: ByteArrayOutputStream, v0: Long) {
        var v = v0
        while (true) {
            if ((v and 0x7FL.inv()) == 0L) { out.write(v.toInt()); return }
            out.write(((v and 0x7F) or 0x80).toInt())
            v = v ushr 7
        }
    }

    private fun encodeVarint(v: Long): ByteArray {
        val out = ByteArrayOutputStream(); writeVarint(out, v); return out.toByteArray()
    }
    private fun decodeVarint(bytes: ByteArray): Long {
        var result = 0L; var shift = 0
        for (b in bytes) { result = result or ((b.toLong() and 0x7F) shl shift); if ((b.toInt() and 0x80) == 0) return result; shift += 7 }
        return result
    }

    private class Reader(private val data: ByteArray) {
        var pos = 0
        fun eof() = pos >= data.size
        fun varint(): Long {
            var result = 0L; var shift = 0
            while (pos < data.size) {
                val b = data[pos++].toInt() and 0xFF
                result = result or ((b.toLong() and 0x7F) shl shift)
                if ((b and 0x80) == 0) return result
                shift += 7
                if (shift > 63) throw IllegalArgumentException("Invalid varint")
            }
            throw EOFException("Truncated varint")
        }
        fun bytes(): ByteArray {
            val len = varint().toInt()
            if (len < 0 || pos + len > data.size) throw EOFException("Truncated bytes")
            val out = data.copyOfRange(pos, pos + len); pos += len; return out
        }
    }
}
