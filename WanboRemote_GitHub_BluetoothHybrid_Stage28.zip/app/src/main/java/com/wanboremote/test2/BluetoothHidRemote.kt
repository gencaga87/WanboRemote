package com.wanboremote.test2

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppQosSettings
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Build
import java.util.concurrent.Executors

/**
 * Bluetooth HID transport kept completely separate from RemoteControl (Wi-Fi).
 *
 * The phone advertises itself as a small keyboard/consumer-control remote.
 * Wi-Fi remains the primary Android TV Remote v2 channel; callers explicitly
 * choose which transport to use for each button, so the two sockets never
 * share state or locks.
 */
class BluetoothHidRemote(private val context: Context) {

    interface Listener {
        fun onBluetoothReady(connected: Boolean)
        fun onBluetoothError(message: String)
    }

    companion object {
        private const val REPORT_KEYBOARD = 1
        private const val REPORT_CONSUMER = 2

        // Standard HID consumer usages.
        const val CONSUMER_POWER = 0x0030
        const val CONSUMER_MENU = 0x0040
        const val CONSUMER_MUTE = 0x00E2
        const val CONSUMER_VOLUME_UP = 0x00E9
        const val CONSUMER_VOLUME_DOWN = 0x00EA
        const val CONSUMER_INPUT_SELECT = 0x0083
        const val CONSUMER_HOME = 0x0223
        const val CONSUMER_BACK = 0x0224

        // Keyboard usages useful for navigation.
        const val KEY_ESC = 0x29
        const val KEY_ENTER = 0x28
        const val KEY_UP = 0x52
        const val KEY_DOWN = 0x51
        const val KEY_LEFT = 0x50
        const val KEY_RIGHT = 0x4F
        const val KEY_F13 = 0x68
        const val KEY_F14 = 0x69
        const val KEY_F15 = 0x6A
        const val KEY_F16 = 0x6B
        const val KEY_F17 = 0x6C
        const val KEY_F18 = 0x6D
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val adapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter

    @Volatile private var hid: BluetoothHidDevice? = null
    @Volatile private var host: BluetoothDevice? = null
    @Volatile private var registered = false
    private var listener: Listener? = null

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(
            pluggedDevice: BluetoothDevice?,
            registeredNow: Boolean
        ) {
            registered = registeredNow
            if (registeredNow) {
                listener?.onBluetoothReady(host != null)
            }
        }

        override fun onConnectionStateChanged(
            device: BluetoothDevice?,
            state: Int
        ) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    host = device
                    listener?.onBluetoothReady(true)
                }
                BluetoothProfile.STATE_DISCONNECTED,
                BluetoothProfile.STATE_DISCONNECTING -> {
                    if (host?.address == device?.address) host = null
                    listener?.onBluetoothReady(false)
                }
            }
        }

        override fun onGetReport(
            device: BluetoothDevice,
            type: Byte,
            id: Byte,
            bufferSize: Int
        ) {
            // We use interrupt OUT reports for commands; no input state needs
            // to be returned to the projector.
        }

        override fun onSetReport(
            device: BluetoothDevice,
            type: Byte,
            id: Byte,
            data: ByteArray
        ) {
            // Host LED/status reports are intentionally ignored.
        }

        override fun onVirtualCableUnplug(device: BluetoothDevice?) {
            if (host?.address == device?.address) host = null
            listener?.onBluetoothReady(false)
        }
    }

    fun setListener(value: Listener?) {
        listener = value
    }

    fun isConnected(): Boolean = hid != null && host != null

    fun start() {
        val bt = adapter ?: run {
            listener?.onBluetoothError("Bu telefonda Bluetooth bulunamadı.")
            return
        }
        if (!bt.isEnabled) {
            listener?.onBluetoothError("Bluetooth kapalı. Telefonun Bluetooth'unu açın.")
            return
        }

        if (Build.VERSION.SDK_INT >= 31 &&
            context.checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            listener?.onBluetoothError("Bluetooth bağlantı izni verilmedi.")
            return
        }

        if (hid != null && registered) return

        bt.getProfileProxy(context, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                if (profile != BluetoothProfile.HID_DEVICE) return
                hid = proxy as BluetoothHidDevice
                registerApp()
            }

            override fun onServiceDisconnected(profile: Int) {
                if (profile == BluetoothProfile.HID_DEVICE) {
                    hid = null
                    registered = false
                    host = null
                    listener?.onBluetoothReady(false)
                }
            }
        }, BluetoothProfile.HID_DEVICE)
    }

    private fun registerApp() {
        val profile = hid ?: return
        val sdp = BluetoothHidDeviceAppSdpSettings(
            "Wanbo Remote",
            "Wanbo hybrid Wi-Fi/Bluetooth remote",
            "OpenAI/WanboRemote",
            BluetoothHidDevice.SUBCLASS1_NONE,
            REPORT_DESCRIPTOR
        )
        executor.execute {
            try {
                // Let the Bluetooth stack choose QoS. We do not reserve a
                // separate bandwidth profile, so this cannot interfere with
                // other Bluetooth services such as audio.
                profile.registerApp(sdp, null, null, executor, callback)
            } catch (e: SecurityException) {
                listener?.onBluetoothError("Bluetooth HID izni reddedildi.")
            } catch (e: Exception) {
                listener?.onBluetoothError("Bluetooth HID başlatılamadı: ${e.message ?: "bilinmeyen hata"}")
            }
        }
    }

    /**
     * Send one consumer-control press followed by release.
     */
    fun sendConsumer(usage: Int): Boolean {
        val profile = hid ?: return false
        val device = host ?: return false
        return try {
            val lo = (usage and 0xFF).toByte()
            val hi = ((usage ushr 8) and 0xFF).toByte()
            profile.sendReport(device, REPORT_CONSUMER, byteArrayOf(lo, hi))
            profile.sendReport(device, REPORT_CONSUMER, byteArrayOf(0, 0))
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Send one keyboard usage press followed by release.
     */
    fun sendKey(usage: Int): Boolean {
        val profile = hid ?: return false
        val device = host ?: return false
        return try {
            val report = byteArrayOf(0, 0, usage.toByte(), 0, 0, 0, 0, 0)
            profile.sendReport(device, REPORT_KEYBOARD, report)
            profile.sendReport(device, REPORT_KEYBOARD, ByteArray(8))
            true
        } catch (_: Exception) {
            false
        }
    }

    fun stop() {
        val profile = hid
        executor.execute {
            try {
                if (profile != null && registered) profile.unregisterApp()
            } catch (_: Exception) {
            }
            registered = false
            host = null
        }
    }

    // Keyboard + Consumer Control. Two report IDs keep the reports
            // independent, so a consumer key can never collide with navigation.
            private val REPORT_DESCRIPTOR = byteArrayOf(
                0x05, 0x01,             // Usage Page (Generic Desktop)
                0x09, 0x06,             // Usage (Keyboard)
                0xA1.toByte(), 0x01,    // Collection (Application)
                0x85.toByte(), 0x01,    // Report ID 1
                0x05, 0x07,             // Usage Page (Keyboard/Keypad)
                0x19, 0xE0.toByte(),    // Usage Minimum (Left Control)
                0x29, 0xE7.toByte(),    // Usage Maximum (Right GUI)
                0x15, 0x00,             // Logical Min
                0x25, 0x01,             // Logical Max
                0x75, 0x01,             // Report Size 1
                0x95, 0x08,             // Report Count 8
                0x81.toByte(), 0x02,    // Input (Data,Var,Abs) modifiers
                0x95, 0x01,
                0x75, 0x08,
                0x81.toByte(), 0x01,    // reserved
                0x95, 0x06,
                0x75, 0x08,
                0x15, 0x00,
                0x25, 0x65,
                0x05, 0x07,
                0x19, 0x00,
                0x29, 0x65,
                0x81.toByte(), 0x00,    // 6 key slots
                0xC0.toByte(),
    
                0x05, 0x0C,             // Usage Page (Consumer)
                0x09, 0x01,             // Usage (Consumer Control)
                0xA1.toByte(), 0x01,
                0x85.toByte(), 0x02,    // Report ID 2
                0x15, 0x00,
                0x26, 0xFF.toByte(), 0x03, // Logical Max 0x03FF
                0x19, 0x00,
                0x2A, 0xFF.toByte(), 0x03,
                0x75, 0x10,             // 16-bit usage
                0x95, 0x01,
                0x81.toByte(), 0x00,
                0xC0.toByte()
            )
}
