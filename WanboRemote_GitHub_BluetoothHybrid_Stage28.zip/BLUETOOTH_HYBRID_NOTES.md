# Wanbo Remote — Wi-Fi + Bluetooth Hybrid

## GitHub Actions

The repository is built directly with Gradle. The workflow no longer expects a ZIP file inside the repository.

Workflow: `.github/workflows/build.yml`

APK artifact: `WanboRemote-BluetoothHybrid-Debug`

## Transport split

- Android TV Remote v2 / Wi-Fi remains the transport for normal Android TV navigation and volume.
- Bluetooth HID is a separate transport for Focus +/-, HDMI 1/2, USB and Projector actions.
- A button is sent through only one transport, so the same action is not duplicated over Wi-Fi and Bluetooth.

## Bluetooth pairing

On Android 12+, the app requests `BLUETOOTH_CONNECT` and `BLUETOOTH_ADVERTISE`.
The phone advertises a HID remote named **Wanbo Remote**. Pair the projector with that device from the projector's Bluetooth settings.

## Important model-specific point

The standard HID keyboard usages are used as placeholders for the WANBO-specific Focus/HDMI/USB/Projector actions. If the projector does not react to those keys, the transport is still working but the WANBO-specific HID usages need to be mapped from the physical remote/model.
