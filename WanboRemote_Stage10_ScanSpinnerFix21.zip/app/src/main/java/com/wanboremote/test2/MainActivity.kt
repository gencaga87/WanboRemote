package com.wanboremote.test2

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.widget.*
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var screen: WanboRemoteView
    private lateinit var nsd: NsdManager
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var discoveredHost: InetAddress? = null
    private var discoveredPort: Int = PAIRING_PORT

    companion object {
        private const val SERVICE_TYPE = "_androidtvremote2._tcp."
        private const val PAIRING_PORT = 6467
        private const val REMOTE_PORT = 6466
    }
    private var discoveredName: String = "--"
    private data class DiscoveredDevice(val name: String, val host: String, val port: Int)
    private val discoveredDevices = mutableListOf<DiscoveredDevice>()
    private val deviceFailureCounts = mutableMapOf<String, Int>()
    private var deviceRowsContainer: LinearLayout? = null
    private var pairingInfoText: TextView? = null
    private var discoveryRefreshButton: TextView? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val availabilityExecutor = Executors.newCachedThreadPool()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var availabilityCheckRunnable: Runnable? = null
    private var discoveryTimeoutRunnable: Runnable? = null
    private var refreshAnimator: ValueAnimator? = null
    private var scanSpinnerDrawable: ScanSpinnerDrawable? = null
    private var isScanningForDevices = false
    private var discoveryScanStartedAt = 0L
    private var remote: RemoteControl? = null
    private var pairingDialog: Dialog? = null

    private val prefs by lazy { getSharedPreferences("wanbo_state", Context.MODE_PRIVATE) }
    private val isPaired: Boolean get() = prefs.getBoolean("paired", false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(3, 7, 12)
        window.navigationBarColor = Color.rgb(3, 7, 12)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(true)
        }
        screen = WanboRemoteView(this)
        setContentView(screen)
        nsd = getSystemService(NSD_SERVICE) as NsdManager
        screen.paired = isPaired
        screen.onAction = { handleAction(it) }
        if (isPaired) {
            // Keep the already-paired device name/connection fresh in the background.
            startDiscovery()
        }
    }

    private fun handleAction(a: WanboRemoteView.Action) {
        when (a) {
            WanboRemoteView.Action.PAIR -> if (isPaired) confirmUnpair() else showPairDialog()
            WanboRemoteView.Action.POWER -> key(RemoteControl.KEY_POWER)
            WanboRemoteView.Action.INPUT -> key(RemoteControl.KEY_TV_INPUT)
            WanboRemoteView.Action.APPS -> key(RemoteControl.KEY_MENU)
            WanboRemoteView.Action.ASSIST -> key(RemoteControl.KEY_VOICE_ASSIST)
            WanboRemoteView.Action.SETTINGS -> key(RemoteControl.KEY_SETTINGS)
            WanboRemoteView.Action.UP -> key(RemoteControl.KEY_DPAD_UP)
            WanboRemoteView.Action.DOWN -> key(RemoteControl.KEY_DPAD_DOWN)
            WanboRemoteView.Action.LEFT -> key(RemoteControl.KEY_DPAD_LEFT)
            WanboRemoteView.Action.RIGHT -> key(RemoteControl.KEY_DPAD_RIGHT)
            WanboRemoteView.Action.OK -> key(RemoteControl.KEY_DPAD_CENTER)
            WanboRemoteView.Action.BACK -> key(RemoteControl.KEY_BACK)
            WanboRemoteView.Action.HOME -> key(RemoteControl.KEY_HOME)
            WanboRemoteView.Action.PROJECTOR -> Toast.makeText(this, "Projektör tuşu için Bluetooth/IR aşaması gerekiyor.", Toast.LENGTH_SHORT).show()
            WanboRemoteView.Action.VOL_UP -> key(RemoteControl.KEY_VOLUME_UP)
            WanboRemoteView.Action.VOL_DOWN -> key(RemoteControl.KEY_VOLUME_DOWN)
            WanboRemoteView.Action.MUTE -> key(RemoteControl.KEY_MUTE)
            WanboRemoteView.Action.FOCUS_PLUS -> key(RemoteControl.KEY_ZOOM_IN)
            WanboRemoteView.Action.FOCUS_MINUS -> key(RemoteControl.KEY_ZOOM_OUT)
            WanboRemoteView.Action.HDMI1 -> key(RemoteControl.KEY_TV_INPUT_HDMI_1)
            WanboRemoteView.Action.HDMI2 -> key(RemoteControl.KEY_TV_INPUT_HDMI_2)
            WanboRemoteView.Action.USB -> key(RemoteControl.KEY_TV_INPUT)
            WanboRemoteView.Action.YOUTUBE -> Toast.makeText(this, "YouTube kısayolu Wi‑Fi kanalında eklenebilir.", Toast.LENGTH_SHORT).show()
            WanboRemoteView.Action.NETFLIX -> Toast.makeText(this, "Netflix kısayolu Wi‑Fi kanalında eklenebilir.", Toast.LENGTH_SHORT).show()
            WanboRemoteView.Action.PRIME -> Toast.makeText(this, "Prime Video kısayolu Wi‑Fi kanalında eklenebilir.", Toast.LENGTH_SHORT).show()
            WanboRemoteView.Action.DISNEY -> Toast.makeText(this, "Disney+ kısayolu Wi‑Fi kanalında eklenebilir.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun key(code: Int) {
        if (remote?.isConnected() == true) remote?.sendKey(code)
        else Toast.makeText(this, "Önce sağ üstteki + ile cihazı eşleştirin.", Toast.LENGTH_SHORT).show()
    }

    private fun startDiscovery() {
        stopDiscovery()
        discoveryTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        discoveryTimeoutRunnable = null

        val dialogOpen = pairingDialog?.isShowing == true
        if (dialogOpen) {
            isScanningForDevices = true
            discoveryScanStartedAt = System.currentTimeMillis()
        }

        synchronized(discoveredDevices) {
            discoveredDevices.clear()
            deviceFailureCounts.clear()
        }
        discoveredHost = null
        discoveredName = "--"
        screen.deviceName = if (isPaired) screen.deviceName else "--"
        if (!isPaired) screen.connected = false
        updatePairingInfo()

        if (dialogOpen) {
            val timeout = Runnable {
                if (pairingDialog?.isShowing == true && isScanningForDevices) {
                    finishDiscoveryScan()
                }
            }
            discoveryTimeoutRunnable = timeout
            // Behave like a normal Wi-Fi scan: scan for a short period, then
            // stop and leave an active manual refresh control.
            mainHandler.postDelayed(timeout, 5000L)
        }

        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {
                runOnUiThread {
                    updatePairingInfo()
                }
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                nsd.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                        runOnUiThread { updatePairingInfo() }
                    }

                    override fun onServiceResolved(info: NsdServiceInfo) {
                        val host = info.host?.hostAddress ?: return
                        val name = info.serviceName?.takeIf { it.isNotBlank() } ?: "Android TV"
                        val port = if (info.port > 0) info.port else REMOTE_PORT

                        // Treat a resolved mDNS service as a discovered device immediately.
                        // The previous version waited for a raw TCP probe before showing the row;
                        // on some Android/Wanbo combinations that probe can fail even though the
                        // mDNS service is valid, leaving the screen stuck on “aranıyor”.
                        // Availability is checked separately in the live list below.
                        synchronized(discoveredDevices) {
                            val key = "$host:$port"
                            deviceFailureCounts[key] = 0
                            val existing = discoveredDevices.indexOfFirst { it.host == host && it.port == port }
                            if (existing >= 0) {
                                // Update the same row when the projector changes its friendly name.
                                discoveredDevices[existing] = DiscoveredDevice(name, host, port)
                            } else if (discoveredDevices.size < 3) {
                                discoveredDevices.add(DiscoveredDevice(name, host, port))
                            }
                        }
                        discoveredHost = info.host
                        // mDNS advertises the remote-control service on 6466.
                        // Pairing is always performed separately on TCP 6467.
                        discoveredPort = PAIRING_PORT
                        discoveredName = name
                        runOnUiThread {
                            // Keep the main screen name synchronized with the live mDNS name.
                            screen.deviceName = name
                            refreshDeviceRows()
                            updatePairingInfo()
                            if (isPaired && remote?.isConnected() != true) connectRemoteInternal(host, name)
                        }
                    }
                })
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                val lostName = serviceInfo.serviceName
                synchronized(discoveredDevices) {
                    discoveredDevices.removeAll { device ->
                        device.name == lostName ||
                            (serviceInfo.port > 0 && device.port == serviceInfo.port && serviceInfo.host?.hostAddress == device.host)
                    }
                    val lostHost = serviceInfo.host?.hostAddress
                    if (lostHost != null) {
                        deviceFailureCounts.keys.removeAll { it.startsWith("$lostHost:") }
                    }
                }
                runOnUiThread {
                    if (!screen.connected) {
                        discoveredName = "--"
                        screen.deviceName = "--"
                    }
                    refreshDeviceRows()
                    updatePairingInfo()
                }
            }

            override fun onDiscoveryStopped(serviceType: String) {
                runOnUiThread {
                    if (pairingDialog?.isShowing == true && isScanningForDevices) {
                        finishDiscoveryScan()
                    } else {
                        updatePairingInfo()
                    }
                }
            }

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                try { nsd.stopServiceDiscovery(this) } catch (_: Exception) {}
                runOnUiThread {
                    updatePairingInfo(forceError = true)
                }
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                try { nsd.stopServiceDiscovery(this) } catch (_: Exception) {}
            }
        }
        discoveryListener = listener
        nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun showPairDialog() {
        if (pairingDialog?.isShowing == true) return

        // Opening this menu starts a fresh Wi-Fi-style discovery scan.
        synchronized(discoveredDevices) { discoveredDevices.clear() }

        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.rgb(7, 16, 25))
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.rgb(30, 148, 255))
            }
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "Cihaz Eşleştir"
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = true
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            includeFontPadding = true
            setOnClickListener { dialog.dismiss() }
        }
        titleRow.addView(title, LinearLayout.LayoutParams(0, dp(52), 1f))
        titleRow.addView(close, LinearLayout.LayoutParams(dp(46), dp(52)))
        root.addView(titleRow)

        val photo = ImageView(this).apply {
            setImageResource(R.drawable.projector_photo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        root.addView(photo, LinearLayout.LayoutParams(-1, dp(46)))

        val infoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val info = TextView(this).apply {
            text = "Wanbo projektör aranıyor..."
            textSize = 14f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(Color.rgb(150, 180, 210))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            includeFontPadding = true
        }
        pairingInfoText = info
        infoRow.addView(info, LinearLayout.LayoutParams(0, dp(34), 1f))

        val refresh = TextView(this).apply {
            text = "Yenile"
            textSize = 14f
            setTextColor(Color.rgb(85, 180, 255))
            gravity = Gravity.CENTER
            includeFontPadding = false
            isClickable = true
            isFocusable = true
            background = null
            setPadding(0, 0, 0, 0)
            setOnClickListener {
                if (!isScanningForDevices) {
                    startDiscovery()
                    startAvailabilityChecks()
                }
            }
        }
        discoveryRefreshButton = refresh
        infoRow.addView(refresh, LinearLayout.LayoutParams(dp(58), dp(34)).apply {
            leftMargin = dp(6)
        })
        root.addView(infoRow, LinearLayout.LayoutParams(-1, dp(38)))

        val rows = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = true
            clipToPadding = true
        }
        deviceRowsContainer = rows
        root.addView(rows, LinearLayout.LayoutParams(-1, dp(238)))

        val cancel = Button(this).apply {
            text = "Kapat"
            textSize = 15f
            setTextColor(Color.WHITE)
            setAllCaps(false)
            minHeight = 0
            minWidth = 0
            background = resources.getDrawable(R.drawable.bg_button, theme)
            setPadding(0, 0, 0, 0)
            setOnClickListener { dialog.dismiss() }
        }
        root.addView(cancel, LinearLayout.LayoutParams(-1, dp(42)).apply {
            topMargin = dp(6)
        })

        dialog.setContentView(root)
        dialog.setCancelable(true)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        pairingDialog = dialog
        dialog.setOnDismissListener {
            deviceRowsContainer = null
            pairingInfoText = null
            refreshAnimator?.cancel()
            refreshAnimator = null
            scanSpinnerDrawable?.stop()
            scanSpinnerDrawable = null
            discoveryRefreshButton?.animate()?.cancel()
            discoveryRefreshButton = null
            pairingInfoText = null
            discoveryTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
            discoveryTimeoutRunnable = null
            isScanningForDevices = false
            stopAvailabilityChecks()
            stopDiscovery()
            // A paired device is rediscovered when needed by the main screen.
        }

        dialog.show()
        val width = (resources.displayMetrics.widthPixels * 0.92f).toInt()
        val height = dp(500).coerceAtMost((resources.displayMetrics.heightPixels * 0.72f).toInt())
        dialog.window?.setLayout(width, height)
        dialog.window?.setGravity(Gravity.CENTER)
        refreshDeviceRows()
        updatePairingInfo()
        startDiscovery()
        startAvailabilityChecks()
    }

    private fun updatePairingInfo(forceError: Boolean = false) {
        val info = pairingInfoText ?: return
        val refresh = discoveryRefreshButton
        val count = synchronized(discoveredDevices) { discoveredDevices.size }

        if (forceError) {
            info.text = "Cihaz araması başlatılamadı."
            info.setTextColor(Color.rgb(255, 135, 135))
        } else if (isScanningForDevices) {
            info.text = "Wanbo projektör aranıyor..."
            info.setTextColor(Color.rgb(150, 180, 210))
        } else if (count == 0) {
            info.text = "Wanbo projektörü bulunamadı"
            info.setTextColor(Color.rgb(255, 170, 120))
        } else if (count == 1) {
            info.text = "Wanbo projektörü bulundu"
            info.setTextColor(Color.rgb(105, 220, 150))
        } else {
            info.text = "Wanbo projektörleri bulundu · $count cihaz"
            info.setTextColor(Color.rgb(105, 220, 150))
        }

        refresh?.let { button ->
            button.isEnabled = !isScanningForDevices
            button.alpha = 1f
            refreshAnimator?.cancel()
            refreshAnimator = null

            if (isScanningForDevices) {
                // Scanning indicator: keep the ring completely still and
                // rotate only a small dot inside the ring, like the video.
                button.text = ""
                button.setTextColor(Color.TRANSPARENT)
                button.rotation = 0f

                scanSpinnerDrawable?.stop()
                val spinner = ScanSpinnerDrawable(button.resources.displayMetrics.density)
                scanSpinnerDrawable = spinner
                button.background = spinner

                val animator = ValueAnimator.ofFloat(0f, 360f).apply {
                    duration = 900L
                    interpolator = LinearInterpolator()
                    repeatCount = ValueAnimator.INFINITE
                    addUpdateListener { animation ->
                        spinner.angle = animation.animatedValue as Float
                    }
                }
                refreshAnimator = animator
                animator.start()
            } else {
                // Scan finished: remove the spinner completely and show the
                // manual refresh action exactly as "Yenile".
                button.rotation = 0f
                button.background = null
                button.text = "Yenile"
                button.setTextColor(Color.rgb(85, 180, 255))
            }
        }
    }

    private fun finishDiscoveryScan() {
        if (!isScanningForDevices) return
        isScanningForDevices = false
        discoveryTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        discoveryTimeoutRunnable = null
        stopDiscovery()
        updatePairingInfo()
        refreshDeviceRows()
    }

    private fun refreshDeviceRows() {
        val container = deviceRowsContainer ?: return
        container.removeAllViews()

        // Only show devices actually discovered through Android TV Remote mDNS.
        val devices = synchronized(discoveredDevices) {
            discoveredDevices
                .distinctBy { "${it.host}:${it.port}" }
                .take(3)
                .toList()
        }

        if (devices.isEmpty()) {
            // The search status is shown only once in the header above.
            // Keep the device area empty while discovery is in progress, like the Android Wi‑Fi list.
            val spacer = Space(this)
            container.addView(spacer, LinearLayout.LayoutParams(-1, dp(24)))
            updatePairingInfo()
            return
        }

        devices.forEachIndexed { index, device ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(5), dp(8), dp(5))
                background = GradientDrawable().apply {
                    setColor(Color.rgb(9, 25, 39))
                    cornerRadius = dp(12).toFloat()
                    setStroke(dp(1), if (index == 0) Color.rgb(20, 145, 255) else Color.rgb(48, 65, 84))
                }
            }

            val icon = ImageView(this).apply {
                setImageResource(R.drawable.projector_photo)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(54), dp(62)))

            val textColumn = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), 0, dp(6), 0)
            }
            val nameText = TextView(this).apply {
                text = device.name
                textSize = 17f
                setTextColor(Color.WHITE)
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                includeFontPadding = true
            }
            val addressText = TextView(this).apply {
                text = "${device.host}:${device.port}"
                textSize = 13f
                setTextColor(Color.rgb(155, 185, 215))
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                includeFontPadding = true
            }
            textColumn.addView(nameText, LinearLayout.LayoutParams(-1, dp(28)))
            textColumn.addView(addressText, LinearLayout.LayoutParams(-1, dp(24)))
            row.addView(textColumn, LinearLayout.LayoutParams(0, dp(62), 1f))

            val pair = Button(this).apply {
                text = "Eşleştir"
                textSize = 13f
                setAllCaps(false)
                setTextColor(Color.WHITE)
                minHeight = 0
                minWidth = 0
                background = resources.getDrawable(R.drawable.bg_button, theme)
                setPadding(dp(5), 0, dp(5), 0)
                setOnClickListener { dialogForDevice(device) }
            }
            row.addView(pair, LinearLayout.LayoutParams(dp(92), dp(44)))

            container.addView(row, LinearLayout.LayoutParams(-1, dp(72)).apply {
                if (index > 0) topMargin = dp(5)
            })
        }
        updatePairingInfo()
    }

    private fun startAvailabilityChecks() {
        stopAvailabilityChecks()
        val runnable = object : Runnable {
            override fun run() {
                val dialogIsOpen = pairingDialog?.isShowing == true && deviceRowsContainer != null
                if (!dialogIsOpen) return

                val snapshot = synchronized(discoveredDevices) { discoveredDevices.toList() }
                snapshot.forEach { device ->
                    availabilityExecutor.execute {
                        val key = "${device.host}:${device.port}"
                        val alive = isRemotePortReachable(device.host, device.port)
                        var removed = false
                        synchronized(discoveredDevices) {
                            if (alive) {
                                deviceFailureCounts[key] = 0
                            } else {
                                val failures = (deviceFailureCounts[key] ?: 0) + 1
                                deviceFailureCounts[key] = failures
                                // mDNS/TCP can briefly disappear during Wi‑Fi transitions.
                                // Remove only after three consecutive failed probes (~6.6 s).
                                if (failures >= 3) {
                                    discoveredDevices.removeAll { it.host == device.host && it.port == device.port }
                                    deviceFailureCounts.remove(key)
                                    removed = true
                                }
                            }
                        }
                        if (removed) {
                            runOnUiThread {
                                refreshDeviceRows()
                                updatePairingInfo()
                            }
                        }
                    }
                }
                mainHandler.postDelayed(this, 2200L)
            }
        }
        availabilityCheckRunnable = runnable
        mainHandler.post(runnable)
    }

    private fun stopAvailabilityChecks() {
        availabilityCheckRunnable?.let { mainHandler.removeCallbacks(it) }
        availabilityCheckRunnable = null
    }

    private fun isRemotePortReachable(host: String, port: Int): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 700)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun dialogForDevice(device: DiscoveredDevice) {
        pairingDialog?.dismiss()
        discoveredHost = runCatching { InetAddress.getByName(device.host) }.getOrNull()
        // The discovered mDNS port is the remote-control port (6466).
        // Never use it for pairing: Android TV Remote v2 pairing is TCP 6467.
        discoveredPort = PAIRING_PORT
        discoveredName = device.name
        if (discoveredHost == null) {
            Toast.makeText(this, "Cihaz IP adresi okunamadı.", Toast.LENGTH_SHORT).show()
            return
        }
        startPairing(device.host, PAIRING_PORT, device.name)
    }

    private fun startPairing(host: String, port: Int, name: String) {
        executor.execute {
            try {
                val identity = ClientIdentity.loadOrCreate(this)
                val pairing = TlsPairing(identity)
                pairing.pair(host, port) {
                    val holder = arrayOfNulls<String>(1)
                    runOnUiThread {
                        val input = EditText(this).apply { hint="Örn. A1B2C3"; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS; setSingleLine(true) }
                        android.app.AlertDialog.Builder(this).setTitle("Projektör PIN'i").setMessage("Projektör ekranındaki 6 haneli HEX kodu girin.").setView(input).setCancelable(false).setPositiveButton("Eşleştir") { _,_ -> holder[0]=input.text.toString() }.setNegativeButton("İptal") { _,_ -> holder[0]="" }.show()
                    }
                    while(holder[0]==null) Thread.sleep(100)
                    holder[0]!!
                }
                // Do not mark the device as paired until the 6466 remote
                // session actually succeeds. This also validates cases where
                // the projector closes the pairing TLS stream without SecretAck.
                runOnUiThread { screen.paired=false; screen.connected=false }
                connectRemoteInternal(host, name, afterPairing=true)
            } catch(e:Exception) { runOnUiThread { screen.paired=false; screen.connected=false; Toast.makeText(this,"Eşleştirme başarısız: ${e.message}",Toast.LENGTH_LONG).show() } }
        }
    }

    private fun connectRemoteInternal(host: String, name: String = discoveredName, afterPairing: Boolean = false) {
        executor.execute {
            try {
                val identity=ClientIdentity.loadOrCreate(this)
                val controller=RemoteControl(identity)
                remote?.close(); remote=controller
                controller.connect(host,
                    onReady={ runOnUiThread {
                        screen.connected=true
                        screen.deviceName=name
                        if (afterPairing) {
                            prefs.edit().putBoolean("paired",true).apply()
                            screen.paired=true
                            Toast.makeText(this,"Eşleştirme tamamlandı.",Toast.LENGTH_SHORT).show()
                        }
                    } },
                    onError={ msg -> runOnUiThread {
                        screen.connected=false
                        if (afterPairing) {
                            screen.paired=false
                            prefs.edit().putBoolean("paired",false).apply()
                            Toast.makeText(this,"PIN gönderildi ancak uzaktan kumanda bağlantısı kurulamadı: $msg",Toast.LENGTH_LONG).show()
                        }
                        screen.deviceName="--"
                    } })
            } catch(e:Exception) {
                runOnUiThread {
                    screen.connected=false
                    if (afterPairing) {
                        screen.paired=false
                        prefs.edit().putBoolean("paired",false).apply()
                        Toast.makeText(this,"Uzaktan kumanda bağlantısı kurulamadı: ${e.message}",Toast.LENGTH_LONG).show()
                    }
                    screen.deviceName="--"
                }
            }
        }
    }

    private fun confirmUnpair() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = GradientDrawable().apply {
                setColor(Color.rgb(7, 16, 25))
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.rgb(30, 148, 255))
            }
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val icon = TextView(this).apply {
            text = "×"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(35, 18, 24))
                setStroke(dp(1), Color.rgb(255, 70, 70))
            }
        }
        header.addView(icon, LinearLayout.LayoutParams(dp(50), dp(50)))

        val title = TextView(this).apply {
            text = "Eşleştirmeyi iptal et?"
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(50), 1f))
        root.addView(header)

        val message = TextView(this).apply {
            text = "Bu Wanbo projektörle bu telefondaki eşleştirme kaldırılacak. Daha sonra cihazı yeniden eşleştirebilirsin."
            textSize = 15f
            setTextColor(Color.rgb(165, 185, 205))
            setPadding(0, dp(14), 0, dp(12))
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(message, LinearLayout.LayoutParams(-1, dp(72)))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val cancel = Button(this).apply {
            text = "Vazgeç"
            textSize = 14f
            setAllCaps(false)
            setTextColor(Color.WHITE)
            minHeight = 0
            minWidth = 0
            background = resources.getDrawable(R.drawable.bg_button, theme)
            setOnClickListener { dialog.dismiss() }
        }
        buttons.addView(cancel, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
            rightMargin = dp(6)
        })

        val remove = Button(this).apply {
            text = "Eşleşmeyi Kaldır"
            textSize = 14f
            setAllCaps(false)
            setTextColor(Color.rgb(255, 105, 105))
            minHeight = 0
            minWidth = 0
            background = GradientDrawable().apply {
                setColor(Color.rgb(35, 18, 24))
                cornerRadius = dp(23).toFloat()
                setStroke(dp(1), Color.rgb(190, 55, 65))
            }
            setOnClickListener {
                prefs.edit().putBoolean("paired", false).apply()
                remote?.close()
                remote = null
                screen.paired = false
                screen.connected = false
                screen.deviceName = "--"
                dialog.dismiss()
            }
        }
        buttons.addView(remove, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
            leftMargin = dp(6)
        })

        root.addView(buttons, LinearLayout.LayoutParams(-1, dp(46)))

        dialog.setContentView(root)
        dialog.setCancelable(true)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
        val width = (resources.displayMetrics.widthPixels * 0.90f).toInt()
        val height = dp(250).coerceAtMost((resources.displayMetrics.heightPixels * 0.45f).toInt())
        dialog.window?.setLayout(width, height)
        dialog.window?.setGravity(Gravity.CENTER)
    }

    private fun stopDiscovery() { discoveryListener?.let { try { nsd.stopServiceDiscovery(it) } catch(_:Exception){} }; discoveryListener=null }
    override fun onDestroy(){
        discoveryTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        discoveryTimeoutRunnable = null
        isScanningForDevices = false
        stopAvailabilityChecks()
        stopDiscovery()
        remote?.close()
        executor.shutdownNow()
        availabilityExecutor.shutdownNow()
        super.onDestroy()
    }

    private class ScanSpinnerDrawable(private val density: Float) : Drawable() {
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.7f * density
            color = Color.rgb(143, 143, 143)
        }
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.rgb(143, 143, 143)
        }
        private val ringRect = RectF()
        var angle: Float = 0f
            set(value) {
                field = value
                invalidateSelf()
            }

        override fun draw(canvas: Canvas) {
            val side = minOf(bounds.width(), bounds.height()).toFloat()
            if (side <= 0f) return

            val cx = bounds.exactCenterX()
            val cy = bounds.exactCenterY()

            // Small, compact ring. The dot travels INSIDE this ring.
            val ringRadius = side * 0.31f
            ringRect.set(
                cx - ringRadius,
                cy - ringRadius,
                cx + ringRadius,
                cy + ringRadius
            )
            canvas.drawOval(ringRect, ringPaint)

            val dotRadius = side * 0.055f
            val orbitRadius = ringRadius - ringPaint.strokeWidth * 0.75f - dotRadius
            val radians = Math.toRadians((angle - 90f).toDouble())
            val dx = (Math.cos(radians) * orbitRadius).toFloat()
            val dy = (Math.sin(radians) * orbitRadius).toFloat()
            canvas.drawCircle(cx + dx, cy + dy, dotRadius, dotPaint)
        }

        fun stop() {
            invalidateSelf()
        }

        override fun setAlpha(alpha: Int) {
            ringPaint.alpha = alpha
            dotPaint.alpha = alpha
        }

        override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
            ringPaint.colorFilter = colorFilter
            dotPaint.colorFilter = colorFilter
        }

        override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
    }

}
