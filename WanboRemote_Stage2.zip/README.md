# Wanbo Remote Stage 2

Stage 2 adds Android TV Remote v2 TLS/PIN pairing to the working mDNS discovery test.

- Discovers `_androidtvremote2._tcp.`
- Connects to pairing port 6467 over TLS
- Creates and persists an RSA-2048 client certificate
- Runs the protobuf pairing handshake
- Accepts the 6-character hexadecimal PIN shown by the projector
- Computes and sends the certificate-bound SHA-256 pairing secret

The project does not hardcode the projector IP.

Reference protocol implementations: tronikos/androidtvremote2 and louis49/androidtv-remote.
