# Wanbo Remote – Stage 13 Header Overlay Fix 24

This build keeps the working remote, pairing, discovery, search UI and PIN dialog unchanged.

Only the main remote background image was corrected to remove the dark rectangular overlay behind the `WANBO REMOTE` header while preserving the projector artwork and title.
