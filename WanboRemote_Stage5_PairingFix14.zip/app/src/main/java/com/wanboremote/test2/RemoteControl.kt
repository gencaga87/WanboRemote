package com.wanboremote.test2

import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyStore
import java.security.cert.X509Certificate
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class RemoteControl(private val identity: ClientIdentity) {
    companion object {
        const val PORT = 6466
        const val KEY_HOME = 3
        const val KEY_BACK = 4
        const val KEY_DPAD_UP = 19
        const val KEY_DPAD_DOWN = 20
        const val KEY_DPAD_LEFT = 21
        const val KEY_DPAD_RIGHT = 22
        const val KEY_DPAD_CENTER = 23
        const val KEY_VOLUME_UP = 24
        const val KEY_VOLUME_DOWN = 25
        const val KEY_POWER = 26
        const val KEY_MUTE = 91
        const val KEY_MENU = 82
        const val KEY_SETTINGS = 176
        const val KEY_ASSIST = 219
        const val KEY_VOICE_ASSIST = 231
        const val KEY_MEDIA_PLAY_PAUSE = 85
        const val KEY_TV_INPUT = 178
        const val KEY_TV_INPUT_HDMI_1 = 243
        const val KEY_TV_INPUT_HDMI_2 = 244
        const val KEY_ZOOM_IN = 168
        const val KEY_ZOOM_OUT = 169
        const val SHORT = 3
    }

    @Volatile private var socket: SSLSocket? = null
    @Volatile private var output: java.io.OutputStream? = null
    @Volatile private var connected = false

    fun connect(host: String, onReady: () -> Unit, onError: (String) -> Unit) {
        Thread {
            try {
                val s = createSocket(host, PORT)
                s.soTimeout = 15_000
                s.startHandshake()
                socket = s
                output = s.outputStream

                // Android TV Remote v2 session handshake is client-first:
                // 1) TX RemoteConfigure (field 1)
                // 2) RX RemoteConfigure (field 1)
                // 3) TX RemoteSetActive (field 2)
                // 4) RX RemoteSetActive (field 2)
                send(configureMessage())

                var frame = Proto.readFrame(s.inputStream)
                var fields = Proto.parseFields(frame)
                if (!fields.any { it.number == 1 }) {
                    throw IllegalStateException("RemoteConfigure cevabı alınamadı")
                }

                send(setActiveMessage())

                // The protocol definition names field 2 as RemoteSetActive, but
                // real Android TV Remote Service implementations commonly reply
                // with RemoteStart (field 40) after accepting active=622. Some
                // devices may also send the empty RemoteSetActive acknowledgement
                // first. Do not require field 2 as the only valid success reply.
                var sessionReady = false
                while (!sessionReady && !s.isClosed) {
                    frame = Proto.readFrame(s.inputStream)
                    fields = Proto.parseFields(frame)

                    // RemoteSetActive acknowledgement.
                    if (fields.any { it.number == 2 }) {
                        sessionReady = true
                    }

                    // RemoteStart is the acknowledgement seen on several actual
                    // Android TV / Google TV implementations, including devices
                    // that send RemoteStart immediately after active=622.
                    if (fields.any { it.number == 40 }) {
                        sessionReady = true
                    }

                    // The TV can send a ping during the handshake. Answer it
                    // immediately instead of treating it as a handshake error.
                    val ping = fields.firstOrNull { it.number == 8 }
                    if (ping != null) {
                        val value = Proto.firstVarint(ping.value, 1) ?: 1L
                        send(pingResponseMessage(value))
                    }

                    // Field 3 is RemoteError. Surface the actual protocol error
                    // instead of reporting a misleading RemoteSetActive error.
                    val remoteError = fields.firstOrNull { it.number == 3 }
                    if (remoteError != null) {
                        throw IllegalStateException("Projektör RemoteError gönderdi")
                    }
                }

                if (!sessionReady) {
                    throw IllegalStateException("Remote oturum başlangıcı alınamadı")
                }

                connected = true
                onReady()

                while (!s.isClosed) {
                    try {
                        frame = Proto.readFrame(s.inputStream)
                        fields = Proto.parseFields(frame)
                        val ping = fields.firstOrNull { it.number == 8 }
                        if (ping != null) {
                            val value = Proto.firstVarint(ping.value, 1) ?: 1L
                            send(pingResponseMessage(value))
                        }
                    } catch (e: java.net.SocketTimeoutException) {
                        // Persistent session can remain idle; the projector may ping us later.
                    }
                }
            } catch (e: Exception) {
                connected = false
                onError(e.message ?: e.javaClass.simpleName)
            } finally {
                connected = false
                try { socket?.close() } catch (_: Exception) {}
                socket = null
                output = null
            }
        }.start()
    }

    fun isConnected(): Boolean = connected

    fun sendKey(keyCode: Int, direction: Int = SHORT) {
        if (!connected) return
        Thread {
            try {
                if (connected) send(keyMessage(keyCode, direction))
            } catch (_: Exception) {
                // Connection thread handles socket failures.
            }
        }.start()
    }

    private fun send(data: ByteArray) {
        synchronized(this) {
            val out = output ?: throw IllegalStateException("Remote bağlantısı hazır değil")
            out.write(Proto.frame(data))
            out.flush()
        }
    }

    private fun configureMessage(): ByteArray {
        val deviceInfo = Proto.Writer().apply {
            string(1, "Wanbo Remote")
            string(2, android.os.Build.MANUFACTURER.ifBlank { "Wanbo Remote" })
            varint(3, 1)
            string(4, "1")
            string(5, "com.wanboremote.test2")
            string(6, "1.0")
        }.toByteArray()

        val configure = Proto.Writer().apply {
            varint(1, 622)
            message(2, deviceInfo)
        }.toByteArray()

        return Proto.Writer().apply {
            message(1, configure)
        }.toByteArray()
    }

    private fun setActiveMessage(): ByteArray {
        val active = Proto.Writer().apply {
            varint(1, 622)
        }.toByteArray()
        return Proto.Writer().apply {
            message(2, active)
        }.toByteArray()
    }

    private fun pingResponseMessage(value: Long): ByteArray {
        val ping = Proto.Writer().apply {
            varint(1, value)
        }.toByteArray()
        return Proto.Writer().apply {
            message(9, ping)
        }.toByteArray()
    }

    private fun keyMessage(keyCode: Int, direction: Int): ByteArray {
        val key = Proto.Writer().apply {
            varint(1, keyCode.toLong())
            varint(2, direction.toLong())
        }.toByteArray()
        return Proto.Writer().apply {
            message(10, key)
        }.toByteArray()
    }

    private fun createSocket(host: String, port: Int): SSLSocket {
        val keyStore = KeyStore.getInstance("PKCS12")
        keyStore.load(null, null)
        keyStore.setKeyEntry(
            "client",
            identity.keyPair.private,
            CharArray(0),
            arrayOf(identity.certificate)
        )

        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(keyStore, CharArray(0))

        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) = Unit
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) = Unit
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }

        val context = SSLContext.getInstance("TLS")
        context.init(
            kmf.keyManagers,
            arrayOf<TrustManager>(trustAll),
            java.security.SecureRandom()
        )

        val raw = Socket()
        raw.connect(InetSocketAddress(host, port), 10_000)
        return (context.socketFactory.createSocket(raw, host, port, true) as SSLSocket).apply {
            enabledProtocols = arrayOf("TLSv1.3", "TLSv1.2")
        }
    }

    fun close() {
        connected = false
        try { socket?.close() } catch (_: Exception) {}
    }
}
