package com.wanboremote.test2

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

object BluetoothScanner {
    data class Result(
        val name: String,
        val address: String,
        val rssi: Int?,
        val source: String,
        val uuids: List<String>,
        val manufacturer: String?
    )

    fun hasScanPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun hasConnectPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    fun adapter(context: Context): BluetoothAdapter? {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        return manager?.adapter
    }

    fun bonded(context: Context): List<Result> {
        val adapter = adapter(context) ?: return emptyList()
        if (!hasConnectPermission(context)) return emptyList()
        return try {
            adapter.bondedDevices.map {
                Result(
                    name = it.name ?: "(isimsiz)",
                    address = it.address ?: "?",
                    rssi = null,
                    source = "PAIRED",
                    uuids = it.uuids?.mapNotNull { u -> u.uuid?.toString() } ?: emptyList(),
                    manufacturer = null
                )
            }.sortedBy { it.name.lowercase() }
        } catch (_: SecurityException) {
            emptyList()
        }
    }

    fun scan(context: Context, durationMs: Long = 12000L, callback: (List<Result>) -> Unit) {
        val adapter = adapter(context)
        if (adapter == null || !adapter.isEnabled || !hasScanPermission(context)) {
            callback(emptyList())
            return
        }

        val scanner: BluetoothLeScanner = try {
            adapter.bluetoothLeScanner
        } catch (_: SecurityException) {
            callback(emptyList())
            return
        } ?: run {
            callback(emptyList())
            return
        }

        val results = LinkedHashMap<String, Result>()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val device = result.device
                val name = try { device.name } catch (_: SecurityException) { null }
                    ?: result.scanRecord?.deviceName
                    ?: "(isimsiz)"
                val uuids = result.scanRecord?.serviceUuids?.map { it.uuid.toString() } ?: emptyList()
                val manufacturer = result.scanRecord?.manufacturerSpecificData?.let { msd ->
                    if (msd.size() > 0) {
                        val id = msd.keyAt(0)
                        val data = msd.get(id)
                        "id=$id bytes=${data?.size ?: 0}"
                    } else null
                }
                results[device.address] = Result(name, device.address, result.rssi, "BLE", uuids, manufacturer)
            }

            override fun onBatchScanResults(batchResults: MutableList<ScanResult>) {
                batchResults.forEach { onScanResult(0, it) }
            }

            override fun onScanFailed(errorCode: Int) {
                callback(results.values.toList())
            }
        }

        try {
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build()
            scanner.startScan(null, settings, cb)
        } catch (_: SecurityException) {
            callback(results.values.toList())
            return
        } catch (_: Exception) {
            callback(results.values.toList())
            return
        }

        Thread {
            try { Thread.sleep(durationMs) } catch (_: InterruptedException) { }
            try { scanner.stopScan(cb) } catch (_: Exception) { }
            callback(results.values.toList())
        }.start()
    }
}
