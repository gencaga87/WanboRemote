# Wanbo Remote

Wanbo Mozart 1 Pro için Android TV Remote v2 tabanlı Android kumanda.

Stage 3: güvenli eşleştirilmiş sertifika ile 6466 remote kanalına bağlanır ve DPAD, OK, Home, Back, ses, mute, güç, input ve temel medya tuşlarını gönderir.


### Input
- HDMI 1: Android/internal input via Android TV Remote key 243.
- HDMI 2: external HDMI input via key 244.
- USB: Android TV Remote v2 has no standard USB input key, so the USB button opens the input selector with KEYCODE_TV_INPUT.
