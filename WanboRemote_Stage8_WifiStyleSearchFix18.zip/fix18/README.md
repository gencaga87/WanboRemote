# WanboRemote Stage 8 – Wi‑Fi Style Device Search Fix 18

This build keeps the working Stage 7 pairing/remote implementation and updates only the live device-list behavior.

- Device rows are added as soon as Android mDNS resolves `_androidtvremote2._tcp.`.
- The header shows the search status only once; the empty list no longer repeats “Wanbo projektör aranıyor...”.
- `Yenile` is plain text with no button background.
- Live availability is checked periodically and a device is removed after three consecutive failed TCP checks, avoiding false removals during brief Wi‑Fi transitions.
- mDNS name changes update the existing row and the main remote screen immediately.
