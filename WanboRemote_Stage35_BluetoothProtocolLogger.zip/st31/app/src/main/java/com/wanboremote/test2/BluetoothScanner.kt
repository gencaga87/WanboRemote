package com.wanboremote.test2

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import java.util.UUID
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

object BluetoothScanner {
    data class Result(
        val name: String,
        val address: String,
        val rssi: Int?,
        val source: String,
        val uuids: List<String>,
        val manufacturer: String?
    )

    fun hasScanPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else {
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun hasConnectPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    fun adapter(context: Context): BluetoothAdapter? {
        val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        return manager?.adapter
    }

    fun bonded(context: Context): List<Result> {
        val adapter = adapter(context) ?: return emptyList()
        if (!hasConnectPermission(context)) return emptyList()
        return try {
            adapter.bondedDevices.map {
                Result(
                    name = it.name ?: "(isimsiz)",
                    address = it.address ?: "?",
                    rssi = null,
                    source = "PAIRED",
                    uuids = it.uuids?.mapNotNull { u -> u.uuid?.toString() } ?: emptyList(),
                    manufacturer = null
                )
            }.sortedBy { it.name.lowercase() }
        } catch (_: SecurityException) {
            emptyList()
        }
    }

    fun scan(context: Context, durationMs: Long = 12000L, callback: (List<Result>) -> Unit) {
        val adapter = adapter(context)
        if (adapter == null || !adapter.isEnabled || !hasScanPermission(context)) {
            callback(emptyList())
            return
        }

        val scanner: BluetoothLeScanner = try {
            adapter.bluetoothLeScanner
        } catch (_: SecurityException) {
            callback(emptyList())
            return
        } ?: run {
            callback(emptyList())
            return
        }

        val results = LinkedHashMap<String, Result>()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val device = result.device
                val name = try { device.name } catch (_: SecurityException) { null }
                    ?: result.scanRecord?.deviceName
                    ?: "(isimsiz)"
                val uuids = result.scanRecord?.serviceUuids?.map { it.uuid.toString() } ?: emptyList()
                val manufacturer = result.scanRecord?.manufacturerSpecificData?.let { msd ->
                    if (msd.size() > 0) {
                        val id = msd.keyAt(0)
                        val data = msd.get(id)
                        "id=$id bytes=${data?.size ?: 0}"
                    } else null
                }
                results[device.address] = Result(name, device.address, result.rssi, "BLE", uuids, manufacturer)
            }

            override fun onBatchScanResults(batchResults: MutableList<ScanResult>) {
                batchResults.forEach { onScanResult(0, it) }
            }

            override fun onScanFailed(errorCode: Int) {
                callback(results.values.toList())
            }
        }

        try {
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build()
            scanner.startScan(null, settings, cb)
        } catch (_: SecurityException) {
            callback(results.values.toList())
            return
        } catch (_: Exception) {
            callback(results.values.toList())
            return
        }

        Thread {
            try { Thread.sleep(durationMs) } catch (_: InterruptedException) { }
            try { scanner.stopScan(cb) } catch (_: Exception) { }
            callback(results.values.toList())
        }.start()
    }
    data class DeepResult(
        val uuid: String,
        val detail: String
    )

    /**
     * Performs a read-only RFCOMM connection test against the custom/non-standard
     * service UUIDs advertised by the paired D1221 device. No bytes are written.
     */
    fun deepInspect(context: Context, deviceName: String = "D1221", callback: (List<DeepResult>) -> Unit) {
        val adapter = adapter(context)
        if (adapter == null || !hasConnectPermission(context)) {
            callback(emptyList())
            return
        }

        val device = try {
            adapter.bondedDevices.firstOrNull {
                (it.name ?: "").equals(deviceName, ignoreCase = true)
            }
        } catch (_: SecurityException) {
            null
        }

        if (device == null) {
            callback(listOf(DeepResult("device", "D1221 eşleşmiş cihazı bulunamadı.")))
            return
        }

        val advertised = try {
            device.uuids?.mapNotNull { it.uuid?.toString() } ?: emptyList()
        } catch (_: SecurityException) {
            emptyList()
        }

        // Only test custom UUIDs here. Standard 0000xxxx-... entries are
        // typically media/input profiles and are not the vendor control channel.
        val candidates = advertised.filter { !it.startsWith("0000") }

        Thread {
            val results = mutableListOf<DeepResult>()
            if (candidates.isEmpty()) {
                results.add(DeepResult("service", "Özel/vendor UUID bulunamadı."))
            } else {
                candidates.forEach { uuidText ->
                    var socket: android.bluetooth.BluetoothSocket? = null
                    try {
                        val uuid = UUID.fromString(uuidText)
                        socket = device.createRfcommSocketToServiceRecord(uuid)
                        socket.connect()
                        val input = socket.inputStream
                        val buffer = ByteArray(256)

                        // BluetoothSocket does not expose a soTimeout property.
                        // Poll InputStream.available() for up to 1.2 seconds so the
                        // probe remains read-only and never blocks indefinitely.
                        val deadline = android.os.SystemClock.elapsedRealtime() + 1200L
                        var n = 0
                        while (android.os.SystemClock.elapsedRealtime() < deadline) {
                            val available = try { input.available() } catch (_: Exception) { 0 }
                            if (available > 0) {
                                n = input.read(buffer, 0, minOf(buffer.size, available))
                                break
                            }
                            Thread.sleep(50)
                        }
                        val hex = if (n > 0) {
                            buffer.copyOf(n).joinToString(" ") { b -> "%02X".format(b.toInt() and 0xFF) }
                        } else "(ilk 1.2 sn içinde veri yok)"
                        results.add(DeepResult(uuidText, "RFCOMM bağlantısı BAŞARILI; RX=$hex"))
                    } catch (e: Exception) {
                        results.add(DeepResult(uuidText, "RFCOMM bağlantısı başarısız: ${e.javaClass.simpleName}: ${e.message ?: ""}".take(220)))
                    } finally {
                        try { socket?.close() } catch (_: Exception) {}
                    }
                }
            }
            callback(results)
        }.start()
    }

    data class ProtocolFrame(
        val index: Int,
        val size: Int,
        val rawHex: String,
        val fields: String,
        val decoded: String
    )

    /**
     * Read-only capture of the Android TV Remote protobuf stream over the paired
     * D1221 custom RFCOMM UUID. No bytes are written to the socket.
     * The capture is intentionally short and passive.
     */
    fun captureRemoteProtocol(
        context: Context,
        deviceName: String = "D1221",
        durationMs: Long = 8000L,
        callback: (List<ProtocolFrame>) -> Unit
    ) {
        val adapter = adapter(context)
        if (adapter == null || !hasConnectPermission(context)) {
            callback(emptyList())
            return
        }

        val device = try {
            adapter.bondedDevices.firstOrNull {
                (it.name ?: "").equals(deviceName, ignoreCase = true)
            }
        } catch (_: SecurityException) { null }

        if (device == null) {
            callback(emptyList())
            return
        }

        val uuidText = try {
            device.uuids?.mapNotNull { it.uuid?.toString() }
                ?.firstOrNull { it.equals("cbbfe0e2-f7f3-4206-84e0-84cbb3d09dfc", ignoreCase = true) }
        } catch (_: SecurityException) { null }

        if (uuidText == null) {
            callback(emptyList())
            return
        }

        Thread {
            val frames = mutableListOf<ProtocolFrame>()
            var socket: android.bluetooth.BluetoothSocket? = null
            try {
                socket = device.createRfcommSocketToServiceRecord(UUID.fromString(uuidText))
                socket.connect()
                val input = socket.inputStream
                val deadline = android.os.SystemClock.elapsedRealtime() + durationMs
                val pending = java.io.ByteArrayOutputStream()

                while (android.os.SystemClock.elapsedRealtime() < deadline && frames.size < 40) {
                    val available = try { input.available() } catch (_: Exception) { 0 }
                    if (available <= 0) {
                        Thread.sleep(40)
                        continue
                    }

                    val buf = ByteArray(minOf(512, available))
                    val n = try { input.read(buf) } catch (_: Exception) { -1 }
                    if (n < 0) break
                    if (n == 0) continue
                    pending.write(buf, 0, n)

                    while (true) {
                        val bytes = pending.toByteArray()
                        val parsed = parseLengthPrefixedFrame(bytes) ?: break
                        val frameBytes = parsed.second
                        val remaining = bytes.copyOfRange(parsed.first, bytes.size)
                        pending.reset()
                        pending.write(remaining)

                        val rawHex = frameBytes.joinToString(" ") { b -> "%02X".format(b.toInt() and 0xFF) }
                        try {
                            val fields = Proto.parseFields(frameBytes)
                            val fieldNames = fields.joinToString(",") { it.number.toString() }
                            val decoded = decodeRemoteFrame(fields)
                            frames += ProtocolFrame(frames.size + 1, frameBytes.size, rawHex, fieldNames, decoded)
                        } catch (e: Exception) {
                            frames += ProtocolFrame(frames.size + 1, frameBytes.size, rawHex, "?", "protobuf parse error: ${e.message ?: e.javaClass.simpleName}")
                        }
                    }
                }
            } catch (_: Exception) {
                // Return whatever was captured before the connection failed.
            } finally {
                try { socket?.close() } catch (_: Exception) {}
                callback(frames)
            }
        }.start()
    }

    /** Returns Pair(nextOffset, payload) when a complete length-prefixed frame exists. */
    private fun parseLengthPrefixedFrame(data: ByteArray): Pair<Int, ByteArray>? {
        if (data.isEmpty()) return null
        var value = 0L
        var shift = 0
        var pos = 0
        while (pos < data.size && shift <= 63) {
            val b = data[pos].toInt() and 0xFF
            pos++
            value = value or ((b.toLong() and 0x7F) shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
        }
        if (pos == data.size && (data[pos - 1].toInt() and 0x80) != 0) return null
        if (value < 0 || value > 1024 * 1024) return null
        val end = pos + value.toInt()
        if (end > data.size) return null
        return end to data.copyOfRange(pos, end)
    }

    private fun decodeRemoteFrame(fields: List<Proto.Field>): String {
        return try {
            val names = fields.map { it.number }
            val parts = mutableListOf<String>()
            fields.firstOrNull { it.number == 2 }?.let {
                parts += "RemoteSetActive active=${Proto.firstVarint(it.value, 1)}"
            }
            fields.firstOrNull { it.number == 8 }?.let {
                parts += "RemotePingRequest val1=${Proto.firstVarint(it.value, 1)} val2=${Proto.firstVarint(it.value, 2)}"
            }
            fields.firstOrNull { it.number == 40 }?.let {
                parts += "RemoteStart started=${Proto.firstVarint(it.value, 1)}"
            }
            fields.firstOrNull { it.number == 50 }?.let { v ->
                parts += "RemoteSetVolumeLevel max=${Proto.firstVarint(v.value, 6)} level=${Proto.firstVarint(v.value, 7)} muted=${Proto.firstVarint(v.value, 8)} playerModel=${Proto.firstString(v.value, 3) ?: "-"}"
            }
            fields.firstOrNull { it.number == 20 }?.let { ime ->
                val appInfo = Proto.firstBytes(ime.value, 1)
                val textStatus = Proto.firstBytes(ime.value, 2)
                val appPackage = appInfo?.let { Proto.firstString(it, 12) }
                val appLabel = appInfo?.let { Proto.firstString(it, 10) }
                val textValue = textStatus?.let { Proto.firstString(it, 2) }
                parts += "RemoteImeKeyInject appPackage=${appPackage ?: "-"} label=${appLabel ?: "-"} textValue=${textValue ?: "-"}"
            }
            if (parts.isEmpty()) "fields=$names" else parts.joinToString(" | ")
        } catch (e: Exception) {
            "fields=${fields.map { it.number }} decodeError=${e.message ?: e.javaClass.simpleName}"
        }
    }

}
