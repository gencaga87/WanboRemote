# Wanbo Remote Stage 2 (fixed build)

This build contains the Stage 2 Android TV Remote v2 pairing test.

- mDNS discovery of `_androidtvremote2._tcp.`
- TLS pairing on port 6467
- RSA-2048 client identity
- 6-character HEX PIN entry
- Persistent pairing identity

The project includes the Bouncy Castle PKIX dependency required for X.509 certificate creation and fixes protobuf varint framing and the Android AlertDialog import.
