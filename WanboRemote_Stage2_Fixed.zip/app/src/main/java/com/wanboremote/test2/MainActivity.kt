package com.wanboremote.test2

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.text.InputType
import android.widget.*
import java.net.InetAddress
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var nsd: NsdManager
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var pairButton: Button
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var discoveredHost: InetAddress? = null
    private var discoveredPort: Int = 6467
    private var discoveredName: String = "Wanbo Mozart 1 Pro"
    private val executor = Executors.newSingleThreadExecutor()

    companion object { private const val SERVICE_TYPE = "_androidtvremote2._tcp." }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        nsd = getSystemService(NSD_SERVICE) as NsdManager
        status = findViewById(R.id.statusText)
        result = findViewById(R.id.resultText)
        pairButton = findViewById(R.id.pairButton)
        findViewById<Button>(R.id.scanButton).setOnClickListener { startDiscovery() }
        pairButton.setOnClickListener { startPairing() }
        startDiscovery()
    }

    private fun startDiscovery() {
        stopDiscovery()
        pairButton.visibility = Button.GONE
        discoveredHost = null
        status.text = "Yerel ağda Mozart 1 Pro aranıyor..."
        result.text = "Aranıyor..."
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) { status.text = "Keşif başladı..." }
            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                nsd.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                        runOnUiThread { status.text = "Cihaz bulundu fakat ayrıntıları alınamadı." }
                    }
                    override fun onServiceResolved(info: NsdServiceInfo) {
                        discoveredHost = info.host
                        discoveredPort = 6467
                        discoveredName = info.serviceName ?: "Wanbo Mozart 1 Pro"
                        val ip = info.host?.hostAddress ?: "IP alınamadı"
                        runOnUiThread {
                            status.text = "Cihaz bulundu!"
                            result.text = "📺 $discoveredName\n\nIP: $ip\nPairing portu: 6467\nServis: ${info.serviceType}\n\nPIN eşleştirmesi için hazır."
                            pairButton.visibility = Button.VISIBLE
                        }
                    }
                })
            }
            override fun onServiceLost(serviceInfo: NsdServiceInfo) { runOnUiThread { status.text = "Cihaz ağdan ayrıldı." } }
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { nsd.stopServiceDiscovery(this); runOnUiThread { status.text = "Keşif başlatılamadı." } }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) { nsd.stopServiceDiscovery(this) }
        }
        discoveryListener = listener
        nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    private fun startPairing() {
        val host = discoveredHost ?: run { status.text = "Önce cihazı bulun."; return }
        pairButton.isEnabled = false
        status.text = "Güvenli bağlantı kuruluyor..."
        executor.execute {
            try {
                val identity = ClientIdentity.loadOrCreate(this)
                val pairing = TlsPairing(identity)
                val resultPair = pairing.pair(host.hostAddress ?: error("IP yok"), discoveredPort) { prompt ->
                    val holder = arrayOfNulls<String>(1)
                    runOnUiThread {
                        val input = EditText(this).apply {
                            hint = "Örn. A1B2C3"
                            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                        }
                        AlertDialog.Builder(this)
                            .setTitle("Projektör PIN'i")
                            .setMessage("Projektör ekranında görünen 6 haneli HEX kodu girin.")
                            .setView(input)
                            .setCancelable(false)
                            .setPositiveButton("Eşleştir") { _, _ -> holder[0] = input.text.toString() }
                            .setNegativeButton("İptal") { _, _ -> holder[0] = "" }
                            .show()
                    }
                    // Wait until the dialog writes the answer. This is only the short human PIN step.
                    while (holder[0] == null) Thread.sleep(100)
                    holder[0]!!
                }
                runOnUiThread {
                    status.text = "🎉 Eşleştirme başarılı!"
                    result.text = "📺 $discoveredName\n\nGüvenli eşleştirme tamamlandı.\n\nSonraki aşamada bu bağlantıyı kullanarak gerçek kumanda tuşlarını göndereceğiz."
                    pairButton.isEnabled = true
                    pairButton.text = "EŞLEŞTİRİLDİ"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Eşleştirme başarısız."
                    result.text = "Hata: ${e.message ?: e.javaClass.simpleName}\n\nProjektörde PIN ekranı çıkmadıysa tekrar deneyin."
                    pairButton.isEnabled = true
                }
            }
        }
    }

    private fun stopDiscovery() {
        discoveryListener?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        discoveryListener = null
    }
    override fun onDestroy() { stopDiscovery(); executor.shutdownNow(); super.onDestroy() }
}
