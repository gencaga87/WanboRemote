# Wanbo Remote – Stage 4 UI

Wanbo Mozart 1 Pro için tek ekranlı, fiziksel kumanda yerleşimine yakın Android kumanda arayüzü.

- Android TV Remote v2 güvenli eşleştirme korunur.
- Sağ üst `+` cihaz eşleştirme penceresini açar.
- Eşleştirme tamamlanınca `+` eşleştirme iptal düğmesine dönüşür.
- D-pad, Home, Back, ses, mute, Assistant ve Android TV ayarları Wi‑Fi Remote v2 üzerinden çalışır.
- Projektörün fiziksel özel tuşları (odak/projektör kısayolu/fiziksel güç) sonraki Bluetooth/IR aşamasında ele alınacaktır.
- Giriş seçimi paneli: HDMI 1 / Android, HDMI 2 / Harici Cihaz, USB / USB Medya.


Stage 5 PairingFix9: exact upstream PIN hash representation and corrected remote handshake.


PairingFix11: reference-style certificate identity, fresh identity storage, current service name, and clearer post-PIN TLS diagnostics.


## Pairing implementation
This UI build restores the pairing implementation from WanboRemote_Stage2_Final5 without changing the UI layer.


## Pairing port fix

The `_androidtvremote2._tcp` mDNS service advertises the remote-control channel on TCP 6466. Android TV Remote v2 pairing itself must use TCP 6467. The device picker may display the discovered service port (6466), but the Pair button always connects to 6467.


RemoteHandshakeFix15: aligns 6466 session handshake with current androidtv-remote reference: wait for TV RemoteConfigure, then reply with RemoteConfigure using package androidtv-remote/appVersion 1.0.0.
