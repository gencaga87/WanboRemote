package com.wanboremote.test2

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.InetAddress
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var nsd: NsdManager
    private lateinit var status: TextView
    private lateinit var statusDot: View
    private lateinit var deviceNameText: TextView
    private lateinit var result: TextView
    private lateinit var pairButton: ImageButton
    private lateinit var remotePanel: LinearLayout
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var discoveredHost: InetAddress? = null
    private var discoveredPort: Int = 6467
    private var discoveredName: String = "Wanbo Mozart 1 Pro"
    private val executor = Executors.newSingleThreadExecutor()
    private var remote: RemoteControl? = null
    private var pairingDialog: AlertDialog? = null

    private val prefs by lazy { getSharedPreferences("wanbo_state", Context.MODE_PRIVATE) }
    private val isPaired: Boolean get() = prefs.getBoolean("paired", false)

    companion object { private const val SERVICE_TYPE = "_androidtvremote2._tcp." }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        nsd = getSystemService(NSD_SERVICE) as NsdManager
        status = findViewById(R.id.statusText)
        statusDot = findViewById(R.id.statusDot)
        deviceNameText = findViewById(R.id.deviceNameText)
        result = findViewById(R.id.resultText)
        setConnectionState(false)
        pairButton = findViewById(R.id.pairButton)
        remotePanel = findViewById(R.id.remotePanel)

        pairButton.setOnClickListener {
            if (isPaired) confirmUnpair() else showPairDialog()
        }

        bindRemoteButtons()
        updatePairButton()
        startDiscovery()
    }

    private fun setConnectionState(connected: Boolean) {
        status.text = if (connected) "Bağlı" else "Bağlı değil"
        statusDot.setBackgroundResource(if (connected) R.drawable.dot_green else R.drawable.dot_red)
    }

    private fun setDeviceName(name: String?) {
        deviceNameText.text = name?.takeIf { it.isNotBlank() } ?: "Android TV"
    }

    private fun updatePairButton() {
        pairButton.setImageResource(if (isPaired) R.drawable.ic_disconnect else R.drawable.ic_add)
        pairButton.contentDescription = if (isPaired) "Eşleştirmeyi iptal et" else "Cihaz eşleştir"
    }

    private fun bindRemoteButtons() {
        findViewById<Button>(R.id.upButton).setOnClickListener { key(RemoteControl.KEY_DPAD_UP) }
        findViewById<Button>(R.id.downButton).setOnClickListener { key(RemoteControl.KEY_DPAD_DOWN) }
        findViewById<Button>(R.id.leftButton).setOnClickListener { key(RemoteControl.KEY_DPAD_LEFT) }
        findViewById<Button>(R.id.rightButton).setOnClickListener { key(RemoteControl.KEY_DPAD_RIGHT) }
        findViewById<Button>(R.id.okButton).setOnClickListener { key(RemoteControl.KEY_DPAD_CENTER) }
        findViewById<ImageButton>(R.id.backButton).setOnClickListener { key(RemoteControl.KEY_BACK) }
        findViewById<ImageButton>(R.id.homeButton).setOnClickListener { key(RemoteControl.KEY_HOME) }
        findViewById<Button>(R.id.volumeDownButton).setOnClickListener { key(RemoteControl.KEY_VOLUME_DOWN) }
        findViewById<Button>(R.id.volumeUpButton).setOnClickListener { key(RemoteControl.KEY_VOLUME_UP) }
        findViewById<ImageButton>(R.id.muteButton).setOnClickListener { key(RemoteControl.KEY_MUTE) }
        findViewById<ImageButton>(R.id.powerButton).setOnClickListener { key(RemoteControl.KEY_POWER) }

        // Physical remote's gear key: Android TV settings on the projector.
        findViewById<ImageButton>(R.id.projectorSettingsButton).setOnClickListener { key(RemoteControl.KEY_SETTINGS) }
        findViewById<ImageButton>(R.id.assistButton).setOnClickListener { key(RemoteControl.KEY_VOICE_ASSIST) }
        findViewById<ImageButton>(R.id.inputButton).setOnClickListener { key(RemoteControl.KEY_TV_INPUT) }
        findViewById<ImageButton>(R.id.projectorButton).setOnClickListener {
            Toast.makeText(this, "Projektörün kendi kısayolu Bluetooth/IR aşamasında bağlanacak.", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.hdmi1Button).setOnClickListener { key(RemoteControl.KEY_TV_INPUT_HDMI_1) }
        findViewById<Button>(R.id.hdmi2Button).setOnClickListener { key(RemoteControl.KEY_TV_INPUT_HDMI_2) }
        findViewById<Button>(R.id.usbButton).setOnClickListener { key(RemoteControl.KEY_TV_INPUT) }
        findViewById<Button>(R.id.projectorFocusMinusButton).setOnClickListener { key(RemoteControl.KEY_ZOOM_OUT) }
        findViewById<Button>(R.id.projectorFocusPlusButton).setOnClickListener { key(RemoteControl.KEY_ZOOM_IN) }
    }

    private fun key(code: Int) {
        if (remote?.isConnected() == true) {
            remote?.sendKey(code)
        } else {
            Toast.makeText(this, "Önce sağ üstteki + ile cihazı eşleştirin.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startDiscovery() {
        stopDiscovery()
        discoveredHost = null
        setConnectionState(false)
        setDeviceName(discoveredName)
        result.text = "Aynı Wi‑Fi ağındaki Wanbo Mozart 1 Pro aranıyor."

        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                nsd.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                        runOnUiThread { setConnectionState(false) }
                    }
                    override fun onServiceResolved(info: NsdServiceInfo) {
                        discoveredHost = info.host
                        discoveredPort = 6467
                        discoveredName = info.serviceName ?: "Wanbo Mozart 1 Pro"
                        val ip = info.host?.hostAddress ?: "IP alınamadı"
                        runOnUiThread {
                            setDeviceName(discoveredName)
                            setConnectionState(remote?.isConnected() == true)
                            result.text = "$discoveredName  •  $ip"
                            if (isPaired && remote?.isConnected() != true) {
                                connectRemoteInternal(ip)
                            }
                        }
                    }
                })
            }
            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                runOnUiThread { setConnectionState(false) }
            }
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                try { nsd.stopServiceDiscovery(this) } catch (_: Exception) {}
                runOnUiThread { setConnectionState(false) }
            }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                try { nsd.stopServiceDiscovery(this) } catch (_: Exception) {}
            }
        }
        discoveryListener = listener
        nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    private fun showPairDialog() {
        if (pairingDialog?.isShowing == true) return

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 8, 28, 8)
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_projector)
            layoutParams = LinearLayout.LayoutParams(-1, 72)
        }
        val message = TextView(this).apply {
            gravity = Gravity.CENTER
            text = if (discoveredHost != null) "$discoveredName\n${discoveredHost?.hostAddress ?: ""}" else "Wanbo Mozart 1 Pro aranıyor..."
            setTextColor(Color.rgb(143, 165, 188))
            textSize = 15f
            setPadding(0, 10, 0, 14)
        }
        val pair = Button(this).apply {
            text = "EŞLEŞTİR"
            isEnabled = discoveredHost != null
            setOnClickListener {
                pairingDialog?.dismiss()
                startPairing()
            }
        }
        box.addView(icon)
        box.addView(message)
        box.addView(pair, LinearLayout.LayoutParams(-1, 52))

        pairingDialog = AlertDialog.Builder(this)
            .setTitle("Cihaz Eşleştir")
            .setView(box)
            .setNegativeButton("İptal", null)
            .create()
        pairingDialog?.setOnShowListener {
            pairingDialog?.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.rgb(22, 135, 255))
        }
        pairingDialog?.show()
    }

    private fun startPairing() {
        val host = discoveredHost ?: run {
            Toast.makeText(this, "Wanbo henüz bulunamadı.", Toast.LENGTH_SHORT).show()
            return
        }
        status.text = "Eşleştirme başlatılıyor..."
        executor.execute {
            try {
                val identity = ClientIdentity.loadOrCreate(this)
                val pairing = TlsPairing(identity)
                pairing.pair(host.hostAddress ?: error("IP yok"), discoveredPort) {
                    val holder = arrayOfNulls<String>(1)
                    runOnUiThread {
                        val input = EditText(this).apply {
                            hint = "Örn. A1B2C3"
                            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                            setSingleLine(true)
                        }
                        AlertDialog.Builder(this)
                            .setTitle("Projektör PIN'i")
                            .setMessage("Projektör ekranında görünen 6 haneli HEX kodu girin.")
                            .setView(input)
                            .setCancelable(false)
                            .setPositiveButton("Eşleştir") { _, _ -> holder[0] = input.text.toString() }
                            .setNegativeButton("İptal") { _, _ -> holder[0] = "" }
                            .show()
                    }
                    while (holder[0] == null) Thread.sleep(100)
                    holder[0]!!
                }
                prefs.edit().putBoolean("paired", true).apply()
                runOnUiThread {
                    updatePairButton()
                    setDeviceName(discoveredName)
                    setConnectionState(false)
                    result.text = "$discoveredName  •  Güvenli eşleştirme tamamlandı"
                }
                connectRemoteInternal(host.hostAddress ?: error("IP yok"))
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Eşleştirme başarısız"
                    result.text = e.message ?: e.javaClass.simpleName
                }
            }
        }
    }

    private fun connectRemoteInternal(host: String) {
        executor.execute {
            try {
                val identity = ClientIdentity.loadOrCreate(this)
                val controller = RemoteControl(identity)
                remote?.close()
                remote = controller
                controller.connect(host,
                    onReady = {
                        runOnUiThread {
                            setDeviceName(discoveredName)
                            setConnectionState(true)
                            result.text = "$discoveredName  •  6466 kumanda kanalı"
                        }
                    },
                    onError = { message ->
                        runOnUiThread {
                            setConnectionState(false)
                            result.text = message
                        }
                    }
                )
            } catch (e: Exception) {
                runOnUiThread {
                    setConnectionState(false)
                    result.text = e.message ?: e.javaClass.simpleName
                }
            }
        }
    }

    private fun confirmUnpair() {
        AlertDialog.Builder(this)
            .setTitle("Eşleştirmeyi iptal et?")
            .setMessage("Bu telefondaki Wanbo eşleştirme durumunu kaldırır ve kumanda bağlantısını kapatır.")
            .setNegativeButton("Vazgeç", null)
            .setPositiveButton("İptal Et") { _, _ ->
                prefs.edit().putBoolean("paired", false).apply()
                remote?.close()
                remote = null
                updatePairButton()
                setConnectionState(false)
                setDeviceName("Android TV")
                result.text = "Yeni cihaz eşleştirmek için sağ üstteki + düğmesine dokunun."
            }
            .show()
    }

    private fun stopDiscovery() {
        discoveryListener?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        discoveryListener = null
    }

    override fun onDestroy() {
        stopDiscovery()
        remote?.close()
        executor.shutdownNow()
        super.onDestroy()
    }
}
