package com.wanboremote.test2

import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class TlsPairing(private val identity: ClientIdentity) {
    data class Result(val serverName: String?)

    fun pair(host: String, port: Int, onPinRequired: (String) -> String): Result {
        val socket = createSocket(host, port)
        socket.soTimeout = 15_000
        socket.startHandshake()
        socket.use {
            val input = it.inputStream
            val output = it.outputStream

            send(output, pairingRequest())
            var frame = Proto.readFrame(input)
            var serverName: String? = null

            while (true) {
                val fields = Proto.parseFields(frame)
                val status = fields.firstOrNull { f -> f.number == 2 }
                    ?.let { f -> decodeVarint(f.value) } ?: 0L

                if (status != 200L) {
                    val detail = when (status) {
                        401L -> "Projektör yapılandırmayı kabul etmedi (401)."
                        402L -> "Projektör PIN gizli anahtarını kabul etmedi (402)."
                        400L -> "Projektör pairing isteğini reddetti (400)."
                        else -> "Projektör pairing durumu: $status"
                    }
                    throw IllegalStateException(detail)
                }

                when {
                    fields.any { it.number == 11 } -> {
                        serverName = Proto.firstString(
                            fields.first { it.number == 11 }.value,
                            1
                        )
                        send(output, optionsMessage())
                    }

                    fields.any { it.number == 20 } -> {
                        send(output, configurationMessage())
                    }

                    fields.any { it.number == 31 } -> {
                        val code = onPinRequired("Projektör ekranındaki 6 haneli HEX PIN'i girin.")
                        send(output, secretMessage(code, socket))
                    }

                    fields.any { it.number == 41 } -> {
                        return Result(serverName)
                    }

                    else -> {
                        throw IllegalStateException(
                            "Beklenmeyen pairing mesajı: ${fields.map { it.number }}"
                        )
                    }
                }

                try {
                    frame = Proto.readFrame(input)
                } catch (e: Exception) {
                    throw IllegalStateException(
                        "PIN gönderildi fakat projektör SecretAck (41) göndermeden bağlantıyı kapattı. " +
                            "Bu sürümde kullanılan PIN özeti protokol referansıyla birebir eşleştirildi; " +
                            "kodun doğruluğunu tekrar kontrol edin.",
                        e
                    )
                }
            }
        }
    }

    private fun createSocket(host: String, port: Int): SSLSocket {
        val keyStore = KeyStore.getInstance("PKCS12")
        keyStore.load(null, null)
        keyStore.setKeyEntry(
            "client",
            identity.keyPair.private,
            CharArray(0),
            arrayOf(identity.certificate)
        )

        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(keyStore, CharArray(0))

        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) = Unit
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) = Unit
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }

        val context = SSLContext.getInstance("TLS")
        context.init(kmf.keyManagers, arrayOf<TrustManager>(trustAll), SecureRandom())

        val raw = Socket()
        raw.connect(InetSocketAddress(host, port), 10_000)
        return (context.socketFactory.createSocket(raw, host, port, true) as SSLSocket).apply {
            enabledProtocols = arrayOf("TLSv1.3", "TLSv1.2")
        }
    }

    private fun pairingRequest(): ByteArray {
        val inner = Proto.Writer().apply {
            // Reference Android TV Remote v2 implementations use "atvremote"
            // as the pairing service name and a short client name.
            string(1, "atvremote")
            string(2, "mDNSRemote")
        }.toByteArray()
        return outer(10, inner)
    }

    private fun optionsMessage(): ByteArray {
        val encoding = Proto.Writer().apply {
            varint(1, 3) // HEXADECIMAL
            varint(2, 6) // six symbols
        }.toByteArray()

        val options = Proto.Writer().apply {
            message(1, encoding) // repeated input_encodings
            varint(3, 1) // preferred_role = INPUT
        }.toByteArray()

        return outer(20, options)
    }

    private fun configurationMessage(): ByteArray {
        val encoding = Proto.Writer().apply {
            varint(1, 3) // HEXADECIMAL
            varint(2, 6)
        }.toByteArray()

        val config = Proto.Writer().apply {
            message(1, encoding)
            varint(2, 1) // client_role = INPUT
        }.toByteArray()

        return outer(30, config)
    }

    /**
     * Exact SHA-256 pairing-secret construction used by the maintained
     * androidtvremote2 implementation:
     *
     *   HEX(client RSA modulus)
     * + HEX(0 + RSA exponent)
     * + HEX(server RSA modulus)
     * + HEX(0 + RSA exponent)
     * + HEX(last 4 digits of PIN)
     *
     * For RSA 65537, the exponent is 0x10001 and therefore becomes
     * 010001 after the one-character zero padding used by the reference.
     */
    private fun secretMessage(codeRaw: String, socket: SSLSocket): ByteArray {
        val code = codeRaw.trim().uppercase()
        if (!Regex("[0-9A-F]{6}").matches(code)) {
            throw IllegalArgumentException("PIN 6 haneli HEX olmalı. Örnek: A1B2C3")
        }

        val clientRsa = identity.certificate.publicKey as java.security.interfaces.RSAPublicKey
        val serverCert = socket.session.peerCertificates.first() as X509Certificate
        val serverRsa = serverCert.publicKey as java.security.interfaces.RSAPublicKey

        val clientMod = bigIntHex(clientRsa.modulus)
        val clientExp = bigIntHexEven(clientRsa.publicExponent)
        val serverMod = bigIntHex(serverRsa.modulus)
        val serverExp = bigIntHexEven(serverRsa.publicExponent)
        val pinTail = hexToBytes(code.substring(2))

        val data = concat(
            hexToBytes(clientMod),
            hexToBytes(clientExp),
            hexToBytes(serverMod),
            hexToBytes(serverExp),
            pinTail
        )

        val secret = MessageDigest.getInstance("SHA-256").digest(data)
        val expectedFirstByte = code.substring(0, 2).toInt(16)
        val actualFirstByte = secret[0].toInt() and 0xFF

        if (actualFirstByte != expectedFirstByte) {
            throw IllegalArgumentException(
                "PIN doğrulanamadı. PIN'in ilk byte özeti $actualFirstByte çıktı, " +
                    "beklenen $expectedFirstByte. Projektörde görünen 6 haneli HEX PIN'i tekrar girin."
            )
        }

        return outer(
            40,
            Proto.Writer().apply { bytes(1, secret) }.toByteArray()
        )
    }

    private fun bigIntHex(value: java.math.BigInteger): String =
        value.toString(16).uppercase()

    private fun bigIntHexEven(value: java.math.BigInteger): String {
        val raw = bigIntHex(value)
        return if (raw.length % 2 == 0) raw else "0$raw"
    }

    private fun concat(vararg parts: ByteArray): ByteArray {
        val total = parts.sumOf { it.size }
        val out = ByteArray(total)
        var offset = 0
        for (part in parts) {
            part.copyInto(out, offset)
            offset += part.size
        }
        return out
    }

    private fun outer(field: Int, nested: ByteArray): ByteArray = Proto.Writer().apply {
        varint(1, 2) // protocol_version
        varint(2, 200) // STATUS_OK
        message(field, nested)
    }.toByteArray()

    private fun send(output: OutputStream, message: ByteArray) {
        output.write(Proto.frame(message))
        output.flush()
    }

    private fun hexToBytes(s: String): ByteArray {
        if (s.length % 2 != 0) throw IllegalArgumentException("Odd-length HEX")
        return ByteArray(s.length / 2) { i ->
            s.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }

    private fun decodeVarint(bytes: ByteArray): Long {
        var result = 0L
        var shift = 0
        for (b in bytes) {
            result = result or ((b.toLong() and 0x7F) shl shift)
            if ((b.toInt() and 0x80) == 0) return result
            shift += 7
        }
        throw IllegalArgumentException("Invalid varint")
    }
}
