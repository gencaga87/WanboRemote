# Wanbo Remote – Stage 4 UI

Wanbo Mozart 1 Pro için tek ekranlı, fiziksel kumanda yerleşimine yakın Android kumanda arayüzü.

- Android TV Remote v2 güvenli eşleştirme korunur.
- Sağ üst `+` cihaz eşleştirme penceresini açar.
- Eşleştirme tamamlanınca `+` eşleştirme iptal düğmesine dönüşür.
- D-pad, Home, Back, ses, mute, Assistant ve Android TV ayarları Wi‑Fi Remote v2 üzerinden çalışır.
- Projektörün fiziksel özel tuşları (odak/projektör kısayolu/fiziksel güç) sonraki Bluetooth/IR aşamasında ele alınacaktır.
- Giriş seçimi paneli: HDMI 1 / Android, HDMI 2 / Harici Cihaz, USB / USB Medya.


Stage 5 PairingFix9: exact upstream PIN hash representation and corrected remote handshake.


PairingFix11: reference-style certificate identity, fresh identity storage, current service name, and clearer post-PIN TLS diagnostics.


PairingFix13: pairing secret byte construction now mirrors the maintained androidtvremote2 reference exactly (RSA exponent 65537 encoded as 010001), and a fresh v3 client certificate identity is used for the test.
