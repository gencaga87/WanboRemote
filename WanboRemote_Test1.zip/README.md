# Wanbo Remote Test 1

Bu ilk test sürümü yalnızca Wanbo Mozart 1 Pro / Android TV Remote v2 mDNS keşfini test eder.

## Amaç

IP adresini sabitlemeden, yerel Wi-Fi üzerinde `_androidtvremote2._tcp` servisinin bulunup bulunmadığını görmek.

## Test

Telefon ve projektör aynı Wi-Fi ağında olmalı.

Uygulamada **MOZART 1 PRO'YU ARA** düğmesine bas.

Cihaz bulunursa adı, IP'si ve servis portu gösterilir.

> Bu sürüm henüz kumanda komutu göndermez ve PIN eşleştirmesi yapmaz.
> Başarılı keşiften sonra ikinci aşamada 6467 üzerinden güvenli PIN eşleştirmesini ekleyeceğiz.

## Telefonda APK oluşturma

Bu proje GitHub'a yüklendiğinde Actions > Build Wanbo Remote Test 1 > Run workflow ile APK üretilebilir.