package com.wanboremote.test1

import android.app.Activity
import android.os.Bundle
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.widget.Button
import android.widget.TextView
import java.net.InetAddress

class MainActivity : Activity() {
    private lateinit var nsd: NsdManager
    private lateinit var status: TextView
    private lateinit var result: TextView
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    companion object {
        private const val SERVICE_TYPE = "_androidtvremote2._tcp."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nsd = getSystemService(NSD_SERVICE) as NsdManager
        status = findViewById(R.id.statusText)
        result = findViewById(R.id.resultText)

        findViewById<Button>(R.id.scanButton).setOnClickListener {
            startDiscovery()
        }
    }

    private fun startDiscovery() {
        stopDiscovery()
        status.text = "Yerel ağda Android TV / Wanbo aranıyor..."
        result.text = "Aranıyor..."

        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {
                status.text = "Keşif başladı: $serviceType"
            }

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                // Android TV Remote v2 advertises this mDNS service.
                nsd.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                        runOnUiThread {
                            status.text = "Cihaz bulundu fakat ayrıntıları alınamadı."
                        }
                    }

                    override fun onServiceResolved(info: NsdServiceInfo) {
                        val host: InetAddress? = info.host
                        val ip = host?.hostAddress ?: "IP alınamadı"
                        val name = info.serviceName ?: "Android TV"
                        val port = info.port

                        runOnUiThread {
                            status.text = "Cihaz bulundu!"
                            result.text =
                                "📺 $name\n\n" +
                                "IP: $ip\n" +
                                "Port: $port\n" +
                                "Servis: ${info.serviceType}\n\n" +
                                "Bu sürüm yalnızca keşif testi yapıyor. " +
                                "Bir sonraki sürümde güvenli eşleştirme (PIN) ekleyeceğiz."
                        }
                    }
                })
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                runOnUiThread {
                    status.text = "Bir cihaz ağdan ayrıldı."
                }
            }

            override fun onDiscoveryStopped(serviceType: String) {
                runOnUiThread {
                    status.text = "Keşif durduruldu."
                }
            }

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                nsd.stopServiceDiscovery(this)
                runOnUiThread {
                    status.text = "Keşif başlatılamadı. Wi-Fi bağlantısını kontrol et."
                }
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
                nsd.stopServiceDiscovery(this)
            }
        }

        discoveryListener = listener
        nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    private fun stopDiscovery() {
        discoveryListener?.let {
            try {
                nsd.stopServiceDiscovery(it)
            } catch (_: Exception) {
            }
        }
        discoveryListener = null
    }

    override fun onDestroy() {
        stopDiscovery()
        super.onDestroy()
    }
}