package com.wanboremote.test2

import android.content.Context
import android.graphics.*
import android.graphics.drawable.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

class WanboRemoteView(context: Context) : View(context) {
    enum class Action {
        PAIR, POWER, INPUT, APPS, ASSIST, SETTINGS,
        UP, DOWN, LEFT, RIGHT, OK, BACK, PROJECTOR, HOME,
        VOL_UP, VOL_DOWN, MUTE, FOCUS_PLUS, FOCUS_MINUS,
        YOUTUBE, NETFLIX, PRIME, DISNEY, HDMI1, HDMI2, USB
    }

    var onAction: ((Action) -> Unit)? = null
    var deviceName: String = "Android TV"
        set(value) { field = value; invalidate() }
    var connected: Boolean = false
        set(value) { field = value; invalidate() }
    var paired: Boolean = false
        set(value) { field = value; invalidate() }

    private val bitmap = BitmapFactory.decodeResource(resources, resources.getIdentifier("wanbo_remote_background", "drawable", context.packageName))
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val overlay = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blue = Color.rgb(24, 151, 255)
    private val white = Color.WHITE

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(2, 7, 12))
        val scale = width.toFloat() / bitmap.width.toFloat()
        val dstW = width.toFloat()
        val dstH = bitmap.height * scale
        val top = 0f
        val dst = RectF(0f, top, dstW, dstH)
        canvas.drawBitmap(bitmap, null, dst, paint)

        // Dynamic connection area replaces the static text from the reference image.
        val sx = scale
        val left = 38f * sx
        val topY = 73f * sx
        val right = 305f * sx
        val bottom = 126f * sx
        overlay.color = Color.rgb(4, 15, 23)
        canvas.drawRect(left, topY, right, bottom, overlay)

        overlay.color = if (connected) Color.rgb(0, 235, 105) else Color.rgb(220, 38, 38)
        canvas.drawCircle(61f * sx, 88f * sx, 9f * sx, overlay)
        overlay.color = if (connected) Color.WHITE else Color.rgb(165, 180, 195)
        overlay.textSize = 20f * sx
        overlay.typeface = Typeface.create("sans", Typeface.NORMAL)
        canvas.drawText(deviceName.take(18), 85f * sx, 94f * sx, overlay)
        overlay.textSize = 20f * sx
        canvas.drawText(if (connected) "Bağlı" else "Bağlı değil", 85f * sx, 119f * sx, overlay)

        // Pair button: replace the reference + with the disconnect symbol after pairing.
        if (paired) {
            val cx = 611f * sx
            val cy = 76f * sx
            overlay.color = Color.rgb(5, 17, 27)
            overlay.style = Paint.Style.FILL
            canvas.drawCircle(cx, cy, 45f * sx, overlay)
            overlay.style = Paint.Style.STROKE
            overlay.strokeWidth = 1.5f * sx
            overlay.color = Color.rgb(32, 157, 255)
            canvas.drawCircle(cx, cy, 45f * sx, overlay)
            overlay.style = Paint.Style.FILL
            overlay.color = white
            overlay.strokeWidth = 7f * sx
            canvas.drawRect(cx - 20f*sx, cy - 3f*sx, cx + 20f*sx, cy + 3f*sx, overlay)
            canvas.drawRect(cx - 3f*sx, cy - 20f*sx, cx + 3f*sx, cy + 20f*sx, overlay)
            overlay.color = Color.rgb(5, 17, 27)
            canvas.drawCircle(cx, cy, 13f*sx, overlay)
            overlay.color = white
            overlay.style = Paint.Style.STROKE
            overlay.strokeWidth = 3f*sx
            canvas.drawCircle(cx, cy, 18f*sx, overlay)
            overlay.style = Paint.Style.FILL
        }
    }

    private fun hit(x: Float, y: Float, l: Int, t: Int, r: Int, b: Int): Boolean =
        x >= l && x <= r && y >= t && y <= b

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val sx = width.toFloat() / bitmap.width.toFloat()
        val x = event.x / sx
        val y = event.y / sx
        val a = when {
            hit(x,y,545,25,675,160) -> Action.PAIR
            hit(x,y,25,180,150,315) -> Action.POWER
            hit(x,y,155,180,275,315) -> Action.INPUT
            hit(x,y,275,180,405,315) -> Action.APPS
            hit(x,y,410,180,535,315) -> Action.ASSIST
            hit(x,y,535,180,675,315) -> Action.SETTINGS
            hit(x,y,245,315,445,445) -> Action.UP
            hit(x,y,150,400,285,585) -> Action.LEFT
            hit(x,y,275,425,420,575) -> Action.OK
            hit(x,y,410,400,545,585) -> Action.RIGHT
            hit(x,y,245,560,445,690) -> Action.DOWN
            hit(x,y,115,640,250,785) -> Action.BACK
            hit(x,y,270,650,420,805) -> Action.PROJECTOR
            hit(x,y,445,640,585,785) -> Action.HOME
            hit(x,y,35,775,180,995) -> if (y < 890) Action.VOL_UP else Action.VOL_DOWN
            hit(x,y,270,805,425,970) -> Action.MUTE
            hit(x,y,505,775,660,995) -> if (y < 890) Action.FOCUS_PLUS else Action.FOCUS_MINUS
            hit(x,y,55,995,340,1070) -> Action.YOUTUBE
            hit(x,y,345,995,650,1070) -> Action.NETFLIX
            hit(x,y,55,1070,340,1145) -> Action.PRIME
            hit(x,y,345,1070,650,1145) -> Action.DISNEY
            hit(x,y,25,1155,240,1315) -> Action.HDMI1
            hit(x,y,240,1155,455,1315) -> Action.HDMI2
            hit(x,y,455,1155,675,1315) -> Action.USB
            else -> null
        }
        if (a != null) onAction?.invoke(a)
        performClick()
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
