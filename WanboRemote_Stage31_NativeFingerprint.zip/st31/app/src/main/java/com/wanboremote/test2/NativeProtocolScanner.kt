package com.wanboremote.test2

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.security.cert.X509Certificate
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import java.util.concurrent.Executors

/**
 * Non-destructive service fingerprinting for the projector LAN host.
 * It only opens TCP/TLS connections and performs safe HTTP GET/HEAD requests.
 * No projector control commands are sent.
 */
object NativeProtocolScanner {
    private val executor = Executors.newSingleThreadExecutor()

    private val ports = intArrayOf(
        80, 443, 554, 8000, 8001, 8002, 8008, 8009, 8080, 8081, 8121,
        8443, 8600, 8700, 8888, 9000, 9999, 10000, 25123, 52020, 52021,
        52022, 52023, 52024, 52025, 53000, 56789,
        6466, 6467,
        51010, 51020, 51030, 51040, 51050, 51060
    )

    data class Result(val port: Int, val detail: String)

    fun scan(host: String, onFinished: (List<Result>) -> Unit) {
        executor.execute {
            val results = mutableListOf<Result>()
            for (port in ports.distinct()) {
                try {
                    probe(host, port)?.let { results.add(it) }
                } catch (_: Exception) {
                }
            }
            results.sortBy { it.port }
            onFinished(results)
        }
    }

    private fun probe(host: String, port: Int): Result? {
        if (port == 8443 || port == 443) {
            return probeTls(host, port)
        }

        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), 500)
                socket.soTimeout = 900
                val detail = when (port) {
                    8008, 8009 -> httpGet(socket, host, port)
                    9000, 8080, 8081, 8121, 8888, 9999, 25123, 53000, 56789 -> httpGet(socket, host, port)
                    else -> "TCP açık"
                }
                Result(port, detail)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun httpGet(socket: Socket, host: String, port: Int): String {
        return try {
            val request = "GET / HTTP/1.1\r\nHost: $host\r\nConnection: close\r\nUser-Agent: WanboRemote-Stage31\r\n\r\n"
            socket.getOutputStream().write(request.toByteArray(StandardCharsets.US_ASCII))
            socket.getOutputStream().flush()

            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8))
            val lines = mutableListOf<String>()
            repeat(8) {
                val line = reader.readLine() ?: return@repeat
                if (line.isNotBlank()) lines.add(line.trim())
            }

            if (lines.isEmpty()) {
                "TCP açık (HTTP yanıtı yok)"
            } else {
                lines.joinToString(" | ").take(500)
            }
        } catch (_: Exception) {
            "TCP açık (HTTP yanıtı yok)"
        }
    }

    private fun probeTls(host: String, port: Int): Result? {
        return try {
            val factory = SSLSocketFactory.getDefault() as SSLSocketFactory
            val socket = factory.createSocket() as SSLSocket
            socket.use {
                it.connect(InetSocketAddress(host, port), 700)
                it.soTimeout = 1200
                it.startHandshake()

                val session = it.session
                val cert = session.peerCertificates.firstOrNull() as? X509Certificate
                val subject = cert?.subjectX500Principal?.name ?: "?"
                val issuer = cert?.issuerX500Principal?.name ?: "?"
                Result(
                    port,
                    "TLS ${session.protocol} cipher=${session.cipherSuite} subject=${subject.take(180)} issuer=${issuer.take(180)}"
                )
            }
        } catch (e: Exception) {
            Result(port, "TCP açık (TLS el sıkışması başarısız: ${e.javaClass.simpleName})")
        }
    }
}
