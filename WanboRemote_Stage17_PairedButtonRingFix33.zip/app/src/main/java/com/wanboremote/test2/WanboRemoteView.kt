package com.wanboremote.test2

import android.content.Context
import android.graphics.*
import android.graphics.drawable.*
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.min

class WanboRemoteView(context: Context) : View(context) {
    enum class Action {
        PAIR, POWER, INPUT, APPS, ASSIST, SETTINGS,
        UP, DOWN, LEFT, RIGHT, OK, BACK, PROJECTOR, HOME,
        VOL_UP, VOL_DOWN, MUTE, FOCUS_PLUS, FOCUS_MINUS,
        YOUTUBE, NETFLIX, PRIME, DISNEY, HDMI1, HDMI2, USB
    }

    var onAction: ((Action) -> Unit)? = null
    var deviceName: String = "--"
        set(value) { field = value; invalidate() }
    var connected: Boolean = false
        set(value) { field = value; invalidate() }
    var paired: Boolean = false
        set(value) { field = value; invalidate() }

    private var pressedAction: Action? = null

    private val bitmap = BitmapFactory.decodeResource(
        resources,
        resources.getIdentifier("wanbo_remote_background", "drawable", context.packageName)
    )
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val overlay = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pressPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blue = Color.rgb(24, 151, 255)
    private val white = Color.WHITE

    init {
        isClickable = true
        isFocusable = true
        isHapticFeedbackEnabled = true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(2, 7, 12))

        // Android 15+ uses edge-to-edge by default. Keep the complete remote
        // between the system status/navigation bars so the top title and bottom
        // input selector are never hidden behind system UI.
        val insets = ViewCompat.getRootWindowInsets(this)
        val topInset = insets?.getInsets(WindowInsetsCompat.Type.systemBars())?.top ?: 0
        val bottomInset = insets?.getInsets(WindowInsetsCompat.Type.systemBars())?.bottom ?: 0
        val availableHeight = (height - topInset - bottomInset).coerceAtLeast(1)
        val scale = min(
            width.toFloat() / bitmap.width.toFloat(),
            availableHeight.toFloat() / bitmap.height.toFloat()
        )
        val contentWidth = bitmap.width * scale
        val contentHeight = bitmap.height * scale
        val originX = (width - contentWidth) / 2f
        val originY = topInset.toFloat()
        canvas.save()
        canvas.translate(originX, originY)
        val dst = RectF(0f, 0f, contentWidth, contentHeight)
        canvas.drawBitmap(bitmap, null, dst, paint)

        // Press feedback is deliberately subtle so the existing artwork is not changed.
        // A small translucent highlight + dark inner shade makes a press immediately visible.
        drawPressFeedback(canvas, pressedAction, scale)

        // Cihaz adı ve bağlantı durumu doğrudan arka plan üzerinde gösterilir;
        // arkadaki panel şeffaftır.
        val sx = scale

        // Cihaz adı ayrı satırda; bağlantı noktası yalnızca durum metninin önünde.
        overlay.color = Color.WHITE
        overlay.textSize = 20f * sx
        overlay.typeface = Typeface.create("sans", Typeface.NORMAL)
        canvas.drawText(if (deviceName.isBlank()) "--" else deviceName.take(18), 85f * sx, 94f * sx, overlay)

        overlay.color = if (connected) Color.rgb(0, 235, 105) else Color.rgb(220, 38, 38)
        canvas.drawCircle(61f * sx, 118f * sx, 9f * sx, overlay)
        overlay.color = if (connected) Color.WHITE else Color.rgb(165, 180, 195)
        overlay.textSize = 20f * sx
        canvas.drawText(if (connected) "Bağlı" else "Bağlı değil", 85f * sx, 124f * sx, overlay)

        // Pair button: use the exact same circle position/size as the + button,
        // but replace the + with a clear X so the action is unmistakably "unpair".
        if (paired) {
            val cx = 611f * sx
            val cy = 76f * sx
            overlay.style = Paint.Style.FILL
            overlay.color = Color.rgb(5, 17, 27)
            canvas.drawCircle(cx, cy, 45f * sx, overlay)
            // Keep the original artwork ring. Do NOT draw a second inner ring here;
            // the previous version created the appearance of another button underneath.

            // Broken-link icon: two chain links separated by a gap and a red slash.
            overlay.color = Color.rgb(235, 240, 246)
            overlay.style = Paint.Style.STROKE
            overlay.strokeWidth = 5f * sx
            overlay.strokeCap = Paint.Cap.ROUND
            val link1 = RectF(cx - 25f*sx, cy - 6f*sx, cx - 1f*sx, cy + 8f*sx)
            val link2 = RectF(cx + 1f*sx, cy - 8f*sx, cx + 25f*sx, cy + 6f*sx)
            canvas.drawRoundRect(link1, 7f*sx, 7f*sx, overlay)
            canvas.drawRoundRect(link2, 7f*sx, 7f*sx, overlay)
            overlay.color = Color.rgb(255, 74, 74)
            overlay.strokeWidth = 5.5f * sx
            canvas.drawLine(cx - 18f*sx, cy + 20f*sx, cx + 18f*sx, cy - 20f*sx, overlay)
            overlay.strokeCap = Paint.Cap.BUTT
            overlay.style = Paint.Style.FILL
        }
        canvas.restore()
    }

    private fun drawPressFeedback(canvas: Canvas, action: Action?, sx: Float) {
        if (action == null) return

        // Press feedback is clipped to the REAL artwork geometry.  It must never
        // float outside a button or cover an icon that belongs to another segment.
        fun fillCircle(cx: Float, cy: Float, r: Float) {
            pressPaint.style = Paint.Style.FILL
            pressPaint.color = Color.argb(54, 255, 255, 255)
            canvas.drawCircle(cx * sx, cy * sx, r * sx, pressPaint)
            pressPaint.style = Paint.Style.STROKE
            pressPaint.strokeWidth = 2.0f * sx
            pressPaint.color = Color.argb(155, 24, 151, 255)
            canvas.drawCircle(cx * sx, cy * sx, (r - 2f) * sx, pressPaint)
            pressPaint.style = Paint.Style.FILL
        }

        fun fillRoundRect(l: Float, t: Float, r: Float, b: Float, radius: Float) {
            val rect = RectF(l * sx, t * sx, r * sx, b * sx)
            pressPaint.style = Paint.Style.FILL
            pressPaint.color = Color.argb(54, 255, 255, 255)
            canvas.drawRoundRect(rect, radius * sx, radius * sx, pressPaint)
            pressPaint.style = Paint.Style.STROKE
            pressPaint.strokeWidth = 2.0f * sx
            pressPaint.color = Color.argb(155, 24, 151, 255)
            canvas.drawRoundRect(
                RectF((l + 2f) * sx, (t + 2f) * sx, (r - 2f) * sx, (b - 2f) * sx),
                (radius - 2f) * sx,
                (radius - 2f) * sx,
                pressPaint
            )
            pressPaint.style = Paint.Style.FILL
        }

        fun fillDpadSector(centerAngle: Float) {
            // D-pad is a four-part ring. Keep the highlight inside one sector,
            // leaving the diagonal separator lines and the OK circle untouched.
            val cx = 345f * sx
            val cy = 460f * sx
            val outer = 166f * sx
            val inner = 78f * sx
            val halfAngle = 42f

            val path = Path()
            val outerRect = RectF(cx - outer, cy - outer, cx + outer, cy + outer)
            val innerRect = RectF(cx - inner, cy - inner, cx + inner, cy + inner)

            path.moveTo(
                cx + inner * kotlin.math.cos(Math.toRadians((centerAngle - halfAngle).toDouble())).toFloat(),
                cy + inner * kotlin.math.sin(Math.toRadians((centerAngle - halfAngle).toDouble())).toFloat()
            )
            path.lineTo(
                cx + outer * kotlin.math.cos(Math.toRadians((centerAngle - halfAngle).toDouble())).toFloat(),
                cy + outer * kotlin.math.sin(Math.toRadians((centerAngle - halfAngle).toDouble())).toFloat()
            )
            path.arcTo(outerRect, centerAngle - halfAngle, halfAngle * 2f, false)
            path.lineTo(
                cx + inner * kotlin.math.cos(Math.toRadians((centerAngle + halfAngle).toDouble())).toFloat(),
                cy + inner * kotlin.math.sin(Math.toRadians((centerAngle + halfAngle).toDouble())).toFloat()
            )
            path.arcTo(innerRect, centerAngle + halfAngle, -halfAngle * 2f, false)
            path.close()

            pressPaint.style = Paint.Style.FILL
            pressPaint.color = Color.argb(54, 255, 255, 255)
            canvas.drawPath(path, pressPaint)

            pressPaint.style = Paint.Style.STROKE
            pressPaint.strokeWidth = 2f * sx
            pressPaint.color = Color.argb(155, 24, 151, 255)
            canvas.drawPath(path, pressPaint)
            pressPaint.style = Paint.Style.FILL
        }

        when (action) {
            Action.PAIR -> fillCircle(613f, 60f, 44f)

            // Top buttons: match the circles already present in the artwork.
            Action.POWER -> fillCircle(90f, 200f, 53f)
            Action.INPUT -> fillCircle(215f, 200f, 53f)
            Action.APPS -> fillCircle(345f, 200f, 53f)
            Action.ASSIST -> fillCircle(475f, 200f, 53f)
            Action.SETTINGS -> fillCircle(605f, 200f, 53f)

            // D-pad sectors follow the four diagonal separator lines.
            Action.UP -> fillDpadSector(-90f)
            Action.RIGHT -> fillDpadSector(0f)
            Action.DOWN -> fillDpadSector(90f)
            Action.LEFT -> fillDpadSector(180f)
            Action.OK -> fillCircle(345f, 460f, 72f)

            Action.BACK -> fillCircle(180f, 640f, 49f)
            Action.HOME -> fillCircle(510f, 640f, 49f)
            Action.PROJECTOR -> fillRoundRect(282f, 638f, 408f, 704f, 32f)
            Action.MUTE -> fillCircle(345f, 830f, 58f)

            // Volume/focus are one tall pill, but + and - are separate touch
            // buttons. The middle speaker/focus icon is deliberately untouched.
            Action.VOL_UP -> fillRoundRect(60f, 728f, 170f, 800f, 24f)
            Action.VOL_DOWN -> fillRoundRect(60f, 865f, 170f, 920f, 24f)
            Action.FOCUS_PLUS -> fillRoundRect(520f, 728f, 630f, 800f, 24f)
            Action.FOCUS_MINUS -> fillRoundRect(520f, 865f, 630f, 920f, 24f)

            Action.YOUTUBE -> fillRoundRect(65f, 961f, 335f, 1018f, 28f)
            Action.NETFLIX -> fillRoundRect(355f, 961f, 625f, 1018f, 28f)
            Action.PRIME -> fillRoundRect(65f, 1030f, 335f, 1088f, 28f)
            Action.DISNEY -> fillRoundRect(355f, 1030f, 625f, 1088f, 28f)

            Action.HDMI1 -> fillRoundRect(42f, 1166f, 230f, 1304f, 26f)
            Action.HDMI2 -> fillRoundRect(250f, 1166f, 445f, 1304f, 26f)
            Action.USB -> fillRoundRect(455f, 1166f, 650f, 1304f, 26f)
        }
    }

    private fun hit(x: Float, y: Float, l: Int, t: Int, r: Int, b: Int): Boolean =
        x >= l && x <= r && y >= t && y <= b

    private fun actionAt(x: Float, y: Float): Action? = when {
        hit(x,y,545,25,675,160) -> Action.PAIR
        hit(x,y,25,180,150,315) -> Action.POWER
        hit(x,y,155,180,275,315) -> Action.INPUT
        hit(x,y,275,180,405,315) -> Action.APPS
        hit(x,y,410,180,535,315) -> Action.ASSIST
        hit(x,y,535,180,675,315) -> Action.SETTINGS
        hit(x,y,245,315,445,445) -> Action.UP
        hit(x,y,150,400,285,585) -> Action.LEFT
        hit(x,y,275,425,420,575) -> Action.OK
        hit(x,y,410,400,545,585) -> Action.RIGHT
        hit(x,y,245,560,445,690) -> Action.DOWN
        hit(x,y,115,640,250,785) -> Action.BACK
        hit(x,y,270,650,420,805) -> Action.PROJECTOR
        hit(x,y,445,640,585,785) -> Action.HOME
        hit(x,y,35,775,180,995) -> if (y < 890) Action.VOL_UP else Action.VOL_DOWN
        hit(x,y,270,805,425,970) -> Action.MUTE
        hit(x,y,505,775,660,995) -> if (y < 890) Action.FOCUS_PLUS else Action.FOCUS_MINUS
        // App and input touch areas are aligned to the exact artwork coordinates.
        hit(x,y,65,961,335,1018) -> Action.YOUTUBE
        hit(x,y,355,961,625,1018) -> Action.NETFLIX
        hit(x,y,65,1030,335,1088) -> Action.PRIME
        hit(x,y,355,1030,625,1088) -> Action.DISNEY
        hit(x,y,42,1166,230,1304) -> Action.HDMI1
        hit(x,y,250,1166,445,1304) -> Action.HDMI2
        hit(x,y,455,1166,650,1304) -> Action.USB
        else -> null
    }

    private fun toRemoteCoordinates(event: MotionEvent): Pair<Float, Float> {
        val insets = ViewCompat.getRootWindowInsets(this)
        val topInset = insets?.getInsets(WindowInsetsCompat.Type.systemBars())?.top ?: 0
        val bottomInset = insets?.getInsets(WindowInsetsCompat.Type.systemBars())?.bottom ?: 0
        val availableHeight = (height - topInset - bottomInset).coerceAtLeast(1)
        val sx = min(
            width.toFloat() / bitmap.width.toFloat(),
            availableHeight.toFloat() / bitmap.height.toFloat()
        )
        val contentWidth = bitmap.width * sx
        val originX = (width - contentWidth) / 2f
        val x = (event.x - originX) / sx
        val stretchedY = (event.y - topInset) / sx

        // The current artwork has no vertical separator offsets. From the app
        // row downward, use the exact bitmap Y coordinate so touch areas sit
        // directly on the visible YouTube/Netflix/Prime/Disney and HDMI/USB
        // buttons instead of one row above them. Keep the older calibration for
        // the upper controls so their already-correct touch behavior is unchanged.
        val y = if (stretchedY >= 950f) {
            stretchedY
        } else {
            when {
                stretchedY < 600f -> stretchedY
                stretchedY < 775f -> stretchedY + 45f
                else -> stretchedY + 80f
            }
        }
        return x to y
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val (x, y) = toRemoteCoordinates(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val action = actionAt(x, y)
                if (action != null) {
                    pressedAction = action
                    performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    invalidate()
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                val action = actionAt(x, y)
                val pressed = pressedAction
                pressedAction = null
                invalidate()

                // Only trigger the command if the finger was released on the same button.
                if (action != null && action == pressed) {
                    onAction?.invoke(action)
                }
                performClick()
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                pressedAction = null
                invalidate()
                return true
            }
        }

        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
